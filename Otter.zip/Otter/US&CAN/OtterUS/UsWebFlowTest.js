// Start
document.addEventListener("DOMContentLoaded", () => {
  if (localStorage.getItem("Paid")) {
    location.href = "/test-area/flow/connect-ofos";
  }
  const form = document.getElementById("wf-form-Email-Form");
  const Data = {};
  const country = "United States";
  const PhoneCode = "";
  const getUrlParam = (name, url = window.location.href) => {
    name = name.replace(/[\[\]]/g, "\\$&");
    var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
      results = regex.exec(url);
    if (!results) return "";
    if (!results[2]) return "";
    return decodeURIComponent(results[2].replace(/\+/g, " "));
  };
  const sendToSf = (unparsedData, action) => {
    const parsedData = {
      "Lead Country": unparsedData.Country,
      LastName: unparsedData.Name + " " + unparsedData["Last-Name"],
      Company: unparsedData["Restaurant-Name"],
      Email: unparsedData.Email,
      "Mobile Phone": PhoneCode + unparsedData["Phone-Number"],
      Role: unparsedData.Role,
      "# Locations": unparsedData.Locations,
      utm_source: getUrlParam("utm_source").replace("{", "").replace("}", ""),
      utm_medium: getUrlParam("utm_medium").replace("{", "").replace("}", ""),
      utm_campaign: getUrlParam("utm_campaign")
        .replace("{", "")
        .replace("}", ""),
      utm_term: getUrlParam("utm_term").replace("{", "").replace("}", ""),
      utm_content: getUrlParam("utm_content").replace("{", "").replace("}", ""),
    };
    fetch("https://hooks.zapier.com/hooks/catch/1999765/b3se5bd/", {
      method: "POST",
      headers: {},
      body: JSON.stringify(parsedData),
      redirect: "follow",
    })
      .then((response) => response.json())
      .then(() => {
        action();
      })
      .catch((error) => console.log("error", error));
  };
  function formatPhoneNumber(phoneNumberString) {
    var cleaned = ("" + phoneNumberString).replace(/\D/g, "");
    var match = cleaned.match(/^(\d{3})(\d{3})(\d{4})$/);
    if (match) {
      return "(" + match[1] + ") " + match[2] + "-" + match[3];
    }
    return null;
  }
  document.getElementById("Phone-Number").addEventListener("keypress", (e) => {
    if (e.target.value.length === 10) {
      e.target.value = formatPhoneNumber(e.target.value);
    }
  });
  form.addEventListener("submit", (e) => {
    localStorage.removeItem("DataCustomer");
    const formData = new FormData(e.target);
    for (var key of formData.keys()) Data[key] = formData.get(key);
    Data["Country"] = country;
    localStorage.setItem("DataCustomer", JSON.stringify(Data));
    sendToSf(Data, () => (location.href = "/test-area/flow/choose-product"));
  });
});

// Free Checkout
document.addEventListener("DOMContentLoaded", () => {
  if (localStorage.getItem("Paid")) {
    location.href = "/test-area/flow/connect-ofos";
  }
  if (localStorage.getItem("DataCustomer") === null)
    location.href = "/test-area/flow/start";
  //Contact Information
  const namep = document.getElementById("name");
  const phonep = document.getElementById("phone");
  const emailp = document.getElementById("email");
  const nameb = document.getElementById("name_buss");
  const locations = document.getElementById("locations");
  //Edit Contact Information
  const edit_firstnm = document.getElementById("Name");
  const edit_lastnm = document.getElementById("Last-Name");
  const edit_phone = document.getElementById("Phone");
  const edit_bussnm = document.getElementById("Business-Name");
  const edit_locations = document.getElementById("Locations");
  const form = document.getElementById("email-form");
  const shipp_form = document.getElementById("shipp-form");
  const shipp_check = document.getElementById("shipp-check");
  //Save edited contact information
  const edit_btn = document.getElementById("edit_btn");
  const save_btn = document.getElementById("save_btn");
  //Check terms and Next button
  const check_terms = document.getElementById("term-check");
  const nextbtn = document.getElementById("next_btn");
  //Data customer
  const strCustomerData = localStorage.getItem("DataCustomer");
  const DataCustomer = JSON.parse(strCustomerData);
  const addr_form = document.getElementById("add-form");
  const PhoneCode = "";
  // Products
  const productCodes = {
    free: "BD0000013",
  };
  // SF call
  const sendToSf = (unparsedData, action) => {
    // Getting products list
    let ProductsChosen = [productCodes.free];
    const parsedData = {
      query: `email = '${unparsedData.Email}' AND country__c = '${unparsedData.Country}' AND LeadSource = 'Inbound - Self Service' AND (Hubster_step__c = 'Creation' OR Hubster_step__c = 'Product_selection')`,
      "# Locations": unparsedData.Locations,
      "# Tablets": 0,
      "# Printers": 0,
      Street: unparsedData.Address + " " + unparsedData.Apt,
      City: unparsedData.City,
      State: unparsedData.State,
      Zip: unparsedData["Postal-Code"],
      StreetS: unparsedData.AddressS + " " + unparsedData.AptS,
      CityS: unparsedData.CityS,
      StateS: unparsedData.StateS,
      ZipS: unparsedData["Postal-CodeS"],
      LastName: unparsedData.Name + " " + unparsedData["Last-Name"],
      "# Locations": unparsedData.Locations,
      Company: unparsedData["Restaurant-Name"],
      "Mobile Phone": PhoneCode + unparsedData["Phone-Number"],
      Products: ProductsChosen.join(";"),
    };
    fetch("https://hooks.zapier.com/hooks/catch/1999765/b3serax/", {
      method: "POST",
      headers: {},
      body: JSON.stringify(parsedData),
      redirect: "follow",
    })
      .then((response) => response.json())
      .then(() => {
        action();
      })
      .catch((error) => console.log("error", error));
  };
  //Fill contact information
  const fillContactInf = () => {
    namep.innerHTML = DataCustomer.Name + " " + DataCustomer["Last-Name"];
    phonep.innerHTML = DataCustomer["Phone-Number"];
    emailp.innerHTML = DataCustomer.Email;
    nameb.innerHTML = DataCustomer["Restaurant-Name"];
    locations.innerHTML = DataCustomer.Locations;
  };
  //Fill edit contact information
  const fillEditConInf = () => {
    edit_firstnm.value = DataCustomer.Name;
    edit_lastnm.value = DataCustomer["Last-Name"];
    edit_phone.value = DataCustomer["Phone-Number"];
    edit_bussnm.value = DataCustomer["Restaurant-Name"];
    edit_locations.value = parseInt(DataCustomer.Locations);
  };
  shipp_check.addEventListener("change", (e) => {
    const cont = document.getElementById("shipp-cont");
    cont.style.display = e.target.checked ? "block" : "none";
  });
  save_btn.addEventListener("click", () => {
    let valid = true;
    [...form.elements].reverse().forEach((element) => {
      valid *= element.checkValidity();
      element.oninput = (e) => {
        e.target.setCustomValidity("");
      };
      if (!element.checkValidity()) {
        element.setCustomValidity("Please check or fill this field");
        element.reportValidity();
        return;
      }
    });
    if (valid) {
      DataCustomer.Name = edit_firstnm.value;
      DataCustomer["Last-Name"] = edit_lastnm.value;
      DataCustomer["Phone-Number"] = edit_phone.value;
      DataCustomer["Restaurant-Name"] = edit_bussnm.value;
      DataCustomer.Locations = edit_locations.value;
      fillContactInf();
      fillEditConInf();
      localStorage.setItem("DataCustomer", JSON.stringify(DataCustomer));
      edit_btn.style.display = "flex";
      save_btn.style.display = "none";
      const editables = document.getElementsByClassName(
        "flow-editable-content"
      );
      editables[0].style.display = "block";
      editables[1].style.display = "none";
    }
  });
  nextbtn.addEventListener("click", (e) => {
    e.preventDefault();
    //validate non edit state
    if (save_btn.style.display === "flex") {
      save_btn.click();
    } else {
      let valid = true;
      let formData = {};
      [...addr_form.elements].reverse().forEach((element) => {
        formData[element.name] = element.value;
        element.oninput = (e) => {
          e.target.setCustomValidity("");
        };
        valid *= element.checkValidity();
        if (!element.checkValidity()) {
          element.setCustomValidity("Please check or fill this field");
          element.reportValidity();
          return;
        }
      });
      if (shipp_check.checked) {
        [...shipp_form.elements].reverse().forEach((element) => {
          formData[element.name] = element.value;
          element.oninput = (e) => {
            e.target.setCustomValidity("");
          };
          valid *= element.checkValidity();
          if (!element.checkValidity()) {
            element.setCustomValidity("Please check or fill this field");
            element.reportValidity();
            return;
          }
        });
      } else {
        Object.keys(formData).forEach((elem) => {
          formData[elem + "S"] = formData[elem];
        });
      }
      if (valid) {
        Object.keys(formData).forEach((key) => {
          DataCustomer[key] = formData[key];
        });
        if (!check_terms.checked) {
          check_terms.setCustomValidity(
            "Accept the Terms of Service before continue to Payment"
          );
          check_terms.reportValidity();
        } else {
          localStorage.setItem("DataCustomer", JSON.stringify(DataCustomer));
          sendToSf(DataCustomer, () => {
            window.location = "/test-area/flow/connect-ofos-free";
          });
        }
      }
    }
  });
  document.getElementById("shipp-cont").style.display = "none";
  fillContactInf();
  fillEditConInf();
});

// Free Creds
document.addEventListener("DOMContentLoaded", () => {
  const firstPage = "/test-area/flow/start";
  const Paid = localStorage.getItem("Paid");
  if (!localStorage.getItem("DataCustomer")) {
    location.href = firstPage;
  }
  const loginsConnected = localStorage.getItem("loginsConnected")
    ? JSON.parse(localStorage.getItem("loginsConnected"))
    : [];
  localStorage.setItem("loginsConnected", JSON.stringify(loginsConnected));
  const DataCustomer = JSON.parse(localStorage.getItem("DataCustomer"));
  const countryCode = "US";
  const nextBtn = document.getElementById("nextBtn");
  const loginsBtns = document.getElementsByClassName(
    "flow-modal-next w-button"
  );
  const loginsModals = document.getElementsByClassName("flow-modal-overlay");
  const loginsCards = document.getElementsByClassName("w-dyn-item");
  const openBtns = document.getElementsByClassName(
    "flow-integration-connect w-button"
  );
  const sendToSf = (unparsedData, action = () => {}) => {
    const parsedData = {
      query: `email = '${unparsedData.Email}' AND country__c = '${unparsedData.Country}' AND LeadSource = 'Inbound - Self Service' AND Hubster_step__c = 'Product_Selection'`,
      PaymentID: "0000000",
      PaymentReceived: true,
    };
    if (!Paid) {
      fetch("https://hooks.zapier.com/hooks/catch/1999765/b3ser87/", {
        method: "POST",
        headers: {},
        body: JSON.stringify(parsedData),
        redirect: "follow",
      })
        .then((response) => response.json())
        .then(() => {
          action();
        })
        .catch((error) => console.log("error", error));
    }
  };
  /*const sendToSfClosed = (unparsedData, DataCustomer, action) => {
    const parsedData = {
      ...unparsedData,
      query: `email = '${DataCustomer.Email}' AND country__c = '${DataCustomer.Country}' AND LeadSource = 'Inbound - Self Service' AND (Hubster_step__c = 'Payment_Received' OR Hubster_step__c = '	
      Product_selection')`,
    };
    fetch("https://hooks.zapier.com/hooks/catch/1999765/b3se5kp/", {
      method: "POST",
      headers: {},
      body: JSON.stringify(parsedData),
      redirect: "follow",
    })
      .then((response) => response.json())
      .then(() => {
        action();
      })
      .catch((error) => console.log("error", error));
  };
  const foodLogins = {
    caviar: {
      email: "",
      pass: "",
    },
    doordash: {
      email: "",
      pass: "",
      notSend: "",
      tabEmail: "",
      tabPass: "",
    },
    postmates: {
      email: "",
      pass: "",
    },
    uberEats: {
      email: "",
      pass: "",
      pin: "",
      notSend: "",
      notSend2: "",
    },
    zuppler: {
      email: "",
      pass: "",
    },
    biteSquad: {
      email: "",
      pass: "",
    },
    chowNow: {
      email: "",
      pass: "",
    },
    waitr: {
      email: "",
      pass: "",
    },
    grubHub: {
      email: "",
      pass: "",
    },
  };
  const foodLoginsKeys = Object.keys(foodLogins);
  const ERROR_MESSAGE = "Please fill this field with a correct value";
  const lockButton = (el) => {
    el.innerHTML = "Connected";
    el.style.pointerEvents = "none";
    el.style.backgroundColor = "#ff5530";
    el.style.borderColor = "#ff5530";
    el.style.color = "#fff";
  };
  let current = "";
  [...loginsCards].forEach((item, indx) => {
    const openLoginBtn = item.getElementsByClassName(
      "flow-integration-connect w-button"
    )[0];
    if (openLoginBtn) {
      openLoginBtn.addEventListener("click", () => {
        current = foodLoginsKeys[indx];
      });
      if (loginsConnected.includes(foodLoginsKeys[indx])) {
        lockButton(openLoginBtn);
      }
    }
  });
  [...loginsBtns].forEach((lBtn, indx) => {
    lBtn.addEventListener("click", () => {
      const loginsKeys = Object.keys(foodLogins[current]);
      const lForm = loginsModals[indx].getElementsByTagName("form")[0];
      let valid = 1;
      [...lForm.elements].forEach((element, indx2) => {
        element.oninput = (e) => {
          e.target.setCustomValidity("");
        };
        if (indx2 < loginsKeys.length) {
          if (!element.checkValidity()) {
            if (
              loginsKeys[indx2] !== "notSend" &&
              loginsKeys[indx2] !== "notSend2"
            ) {
              valid = 0;
              element.setCustomValidity(ERROR_MESSAGE);
              element.reportValidity();
            }
          } else {
            foodLogins[current][loginsKeys[indx2]] = element.value;
          }
          if (!valid) {
            return;
          }
        }
      });
      if (valid) {
        let zapData = {};
        Object.keys(foodLogins[current]).forEach((key) => {
          zapData[current + key] = foodLogins[current][key];
        });
        sendToSfClosed(zapData, DataCustomer, () => {
          loginsConnected.push(current);
          localStorage.setItem(
            "loginsConnected",
            JSON.stringify(loginsConnected)
          );
          loginsModals[indx].style.display = "none";
          lockButton(openBtns[indx]);
        });
      }
    });
  });
  nextBtn.addEventListener("click", (e) => {
    e.preventDefault();
    if (loginsConnected.length === 0) {
      alert(
        "Please add your login information to at least one delivery partner "
      );
    } else {
      localStorage.clear();
      window.location = "/test-area/flow/demo-video";
    }
  });*/
  setTimeout(() => {
    sendToSf(DataCustomer, () => {
      localStorage.setItem("Paid", true);
      localStorage.clear();
      location.href = `https://manager-staging.tryotter.com/sign-up/?email=${DataCustomer.Email}&country=${DataCustomer.Country}&phone=${DataCustomer["Phone-Number"]}&name=${DataCustomer.Name}%20${DataCustomer["Last-Name"]}&restaurantName=${DataCustomer["Restaurant-Name"]}`;
    });
  }, 10000);
});

// Essentials Addons
document.addEventListener("DOMContentLoaded", () => {
  if (localStorage.getItem("Paid")) {
    location.href = "/test-area/flow/connect-ofos";
  }
  if (localStorage.getItem("DataCustomer") === null) {
    location.href = "/test-area/flow/start";
  }
  //Data & Data customer
  const DataCustomer = JSON.parse(localStorage.getItem("DataCustomer"));
  const strData = localStorage.getItem("Data");
  let Data = JSON.parse(strData);
  const next_btn = document.getElementById("next_btn");
  const currency = "$";
  //prices
  const price_per_location = parseInt(
    document
      .getElementById("price_per_location")
      .innerHTML.replace("from " + currency, ""),
    ""
  );
  const tablets = parseInt(
    document.getElementById("per_tablet").innerHTML.replace(currency, "")
  );
  const printers = parseInt(
    document.getElementById("per_printer").innerHTML.replace(currency, "")
  );
  const total = document.getElementById("step2-total2");
  //number inputs
  const num_locations = document.getElementById("Total-Locations");
  const num_tablets = document.getElementById("Total-Tablets");
  const num_printers = document.getElementById("Total-Printers");
  const checkOwnTablet = document.getElementById("Own-Tablet");
  const MoreTablets = document.getElementById("MoreTablets");
  const MorePrinters = document.getElementById("MorePrinters");
  //flags add-ins prices
  const Addons = {
    ia: {
      selected: false,
      price: 0,
      isCharged: true,
    },
    ld: {
      selected: false,
      price: 0,
      isCharged: true,
    },
    m86: {
      selected: false,
      price: 0,
      isCharged: true,
    },
    pos: {
      selected: false,
      price: 0,
      isCharged: false,
    },
    hos: {
      selected: false,
      price: 0,
      isCharged: false,
    },
    ps: {
      selected: false,
      price: 0,
      isCharged: true,
    },
  };
  //Initialize number inputs
  Data["Total-Price-Tablets"] = tablets * num_tablets.value;
  num_locations.value = parseInt(DataCustomer.Locations);
  num_tablets.value = 0;
  num_printers.value = 0;
  //Total
  render_total = () => {
    let totaln = parseInt(
      price_per_location * num_locations.value +
        tablets * num_tablets.value +
        printers * num_printers.value
    );
    Object.keys(Addons).forEach((key) => {
      const addOn = Addons[key];
      totaln += parseInt(
        addOn.selected * addOn.isCharged * addOn.price * num_locations.value
      );
    });
    total.innerHTML = "$" + totaln + ".00";
  };
  num_locations.addEventListener("change", (e) => {
    if (parseInt(e.target.value) < parseInt(num_tablets.value)) {
      num_tablets.value = e.target.value;
    }
    if (parseInt(e.target.value) < parseInt(num_printers.value)) {
      num_printers.value = e.target.value;
    }
    render_total();
  });
  num_tablets.addEventListener("change", (e) => {
    if (parseInt(e.target.value) > parseInt(num_locations.value)) {
      e.target.value = num_locations.value;
    }
    render_total();
  });
  num_printers.addEventListener("change", (e) => {
    if (parseInt(e.target.value) > parseInt(num_locations.value)) {
      e.target.value = num_locations.value;
    }
    render_total();
  });
  num_tablets.oninput = (e) => {
    num_tablets.setCustomValidity("");
  };
  //Add-ons
  Object.keys(Addons).forEach((key) => {
    const addOnPrice = document.getElementById(key + "Price");
    Addons[key].price = addOnPrice
      ? parseInt(document.getElementById(key + "Price").innerHTML)
      : 0;
    const Btn = document.getElementById(key + "Btn");
    const Cont = document.getElementById(key + "Cont");
    if (Cont && Btn) {
      Cont.addEventListener("click", () => {
        Addons[key].selected = !Addons[key].selected;
        if (Addons[key].isCharged) {
          Btn.innerHTML = Addons[key].selected ? "Added" : "Add to cart";
        } else {
          Btn.innerHTML = Addons[key].selected ? "Requested" : "Request access";
        }
        Btn.style.backgroundColor = Addons[key].selected
          ? "#efefef"
          : "#ff5530";
        Cont.style.backgroundColor = Addons[key].selected ? "#fff" : "#f8f8f8";
        render_total();
      });
    }
  });
  //check own tablet
  const OwntabletOrNot = () => {
    if (checkOwnTablet.checked === true) {
      num_tablets.value = 0;
      num_tablets.disabled = true;
      render_total();
    } else {
      num_tablets.disabled = false;
      render_total();
    }
  };
  checkOwnTablet.addEventListener("change", () => {
    OwntabletOrNot();
  });
  //Fill Data
  next_btn.addEventListener("click", () => {
    if (parseInt(num_tablets.value) <= 0 && !checkOwnTablet.checked) {
      num_tablets.setCustomValidity(
        "Please select at least 1 Tablet or Check 'I already have my own tablet"
      );
      num_tablets.reportValidity();
    } else {
      Data.Locations = num_locations.value;
      Data["Total-Printers"] = num_printers.value;
      Data["Total-Tablets"] = num_tablets.value;
      Data["Own-Tablet"] = checkOwnTablet.checked;
      Data["Addons"] = Addons;
      Data["Printers"] = printers; //Price
      Data["Tablets"] = tablets; //Price
      Data.MorePrinters = MorePrinters.checked;
      Data.MoreTablets = MoreTablets.checked;
      localStorage.setItem(
        "DataCustomer",
        JSON.stringify({ ...DataCustomer, ...Data })
      );
      window.location = "/test-area/flow/confirm-info-essentials";
    }
  });
  render_total();
});

// Essentials Checkout
document.addEventListener("DOMContentLoaded", () => {
  // Constants
  const currency = "$";
  const PhoneCode = "";
  const moonClrkDomains = {
    "otter-draft.webflow.io": "5f5dcnj9hoyi",
    "www.tryotter.com": "5cewnfjrkyaq",
  };
  let grandTotal = 0;
  //Contact Information
  const namep = document.getElementById("name");
  const phonep = document.getElementById("phone");
  const emailp = document.getElementById("email");
  const nameb = document.getElementById("name_buss");
  //Edit Contact Information
  const edit_firstnm = document.getElementById("Name");
  const edit_lastnm = document.getElementById("Last-Name");
  const edit_phone = document.getElementById("Phone");
  const edit_bussnm = document.getElementById("Business-Name");
  const form = document.getElementById("email-form");
  const addr_form = document.getElementById("add-form");
  const shipp_form = document.getElementById("shipp-form");
  const shipp_check = document.getElementById("shipp-check");
  //Save edited contact information
  const edit_btn = document.getElementById("edit_btn");
  const save_btn = document.getElementById("save_btn");
  //Check terms and Next button
  const check_terms = document.getElementById("term-check");
  const nextbtn = document.getElementById("next_btn");
  //Data customer
  const strCustomerData = localStorage.getItem("DataCustomer");
  const DataCustomer = JSON.parse(strCustomerData);
  const Addons = DataCustomer.Addons;
  // Prices
  const price_per_location = parseInt(
    document
      .getElementById("price_per_location")
      .innerHTML.replace(currency, ""),
    ""
  );
  const total = document.getElementById("step2-total");
  const total2 = document.getElementById("step2-total2");
  //number inputs
  const num_locations = document.getElementById("Total-Locations");
  const num_tablets = document.getElementById("Total-Tablets");
  const num_printers = document.getElementById("Total-Printers");
  // Prices
  const tablets = DataCustomer.Tablets;
  const printers = DataCustomer.Printers;
  // Products
  const products = {
    free: "BD0000013",
    essentials: "BD0000014",
    core: "BD0000016",
    pro: "BD0000015",
    Tablet: "HW0000030",
    OwnTablet: "HW0000024",
    Printer: "HW0000029",
    NoPrinter: "HW0000035",
    ia: "AD0000008",
    ld: "AD0000007",
    m86: "AD0000005;AD0000013",
    hos: "AD0000035",
  };
  // SF call
  const sendToSf = (unparsedData, action) => {
    // Getting products list
    let ProductsChosen = [products.essentials];
    // Get hardware
    const printerProdKey =
      parseInt(unparsedData["Total-Printers"]) == 0 ? "NoPrinter" : "Printer";
    ProductsChosen.push(products[printerProdKey]);

    if (parseInt(unparsedData["Total-Tablets"]) > 0) {
      ProductsChosen.push(products.Tablet);
    }
    if (unparsedData["Own-Tablet"]) {
      ProductsChosen.push(products.OwnTablet);
    }

    Object.keys(Addons).forEach((key) => {
      if (products[key]) {
        if (Addons[key].selected && Addons[key].isCharged) {
          ProductsChosen.push(products[key]);
        }
      }
    });

    const parsedData = {
      query: `email = '${unparsedData.Email}' AND country__c = '${unparsedData.Country}' AND (LeadSource = 'Inbound - Self Service') AND (Hubster_step__c = 'Creation' OR Hubster_step__c = 'Product_selection')`,
      "# Locations": unparsedData.Locations,
      "# Tablets": unparsedData["Total-Tablets"],
      "# Printers": unparsedData["Total-Printers"],
      Street: unparsedData.Address + " " + unparsedData.Apt,
      City: unparsedData.City,
      State: unparsedData.State,
      Zip: unparsedData["Postal-Code"],
      StreetS: unparsedData.AddressS + " " + unparsedData.AptS,
      CityS: unparsedData.CityS,
      StateS: unparsedData.StateS,
      ZipS: unparsedData["Postal-CodeS"],
      Products: ProductsChosen.join(";"),
      PosInterest: Addons.pos ? Addons.pos.selected : false,
      NeedMoreTablets: unparsedData.MoreTablets,
      NeedMorePrinters: unparsedData.MorePrinters,
      LastName: unparsedData.Name + " " + unparsedData["Last-Name"],
      HandoffsInterest: Addons.hos ? Addons.hos.selected : false,
      Company: unparsedData["Restaurant-Name"],
      "Mobile Phone": PhoneCode + unparsedData["Phone-Number"],
      ...unparsedData.foodLogins,
    };
    fetch("https://hooks.zapier.com/hooks/catch/1999765/b3serax/", {
      method: "POST",
      headers: {},
      body: JSON.stringify(parsedData),
      redirect: "follow",
    })
      .then((response) => response.json())
      .then(() => {
        action();
      })
      .catch((error) => console.log("error", error));
  };
  const foodLogins = [
    "uberEats",
    "grubHub",
    "caviar",
    "doordash",
    "postmates",
    "biteSquad",
    "chowNow",
    "waitr",
    "zuppler",
  ];
  const parseFoodLogins = () => {
    let data = {};
    const cards = document.getElementsByClassName(
      "flow-confirm-ofo-button w-inline-block"
    );
    [...cards].forEach((card, indx) => {
      if (card.style.borderColor === "rgb(255, 85, 48)") {
        data[foodLogins[indx]] = true;
      }
    });
    return data;
  };
});
document.addEventListener("DOMContentLoaded", () => {
  if (localStorage.getItem("Paid")) {
    location.href = "/test-area/flow/connect-ofos";
  }
  if (localStorage.getItem("DataCustomer") === null) {
    location.href = "/test-area/flow/start";
  }
  // Intializa inputs
  num_locations.value = parseInt(DataCustomer.Locations);
  num_tablets.value = parseInt(DataCustomer["Total-Tablets"]);
  num_printers.value = parseInt(DataCustomer["Total-Printers"]);
  //Fill contact information
  const fillContactInf = () => {
    namep.innerHTML = DataCustomer.Name + " " + DataCustomer["Last-Name"];
    phonep.innerHTML = DataCustomer["Phone-Number"];
    emailp.innerHTML = DataCustomer.Email;
    nameb.innerHTML = DataCustomer["Restaurant-Name"];
  };
  //Fill edit contact information
  const fillEditConInf = () => {
    edit_firstnm.value = DataCustomer.Name;
    edit_lastnm.value = DataCustomer["Last-Name"];
    edit_phone.value = DataCustomer["Phone-Number"];
    edit_bussnm.value = DataCustomer["Restaurant-Name"];
  };
  shipp_check.addEventListener("change", (e) => {
    const cont = document.getElementById("shipp-cont");
    cont.style.display = e.target.checked ? "block" : "none";
  });
  // render function
  render_total = () => {
    const totalTablets = parseInt(tablets * num_tablets.value);
    const totalPrinters = parseInt(printers * num_printers.value);
    let totaln = parseInt(
      price_per_location * num_locations.value + totalTablets + totalPrinters
    );
    Object.keys(Addons).forEach((key) => {
      const addOn = Addons[key];
      const totalAddon = parseInt(
        addOn.selected * addOn.isCharged * addOn.price * num_locations.value
      );
      const Row = document.getElementById(key + "Total");
      if (Row) {
        Row.innerHTML = currency + totalAddon + ".00";
        totaln += totalAddon;
      }
    });
    document.getElementById("Total-Price-Printers").innerHTML =
      currency + totalPrinters + ".00";
    document.getElementById("Total-Price-Tablets").innerHTML =
      currency + totalTablets + ".00";
    total.innerHTML = currency + totaln + ".00";
    total2.innerHTML = currency + totaln + ".00";
    grandTotal = totaln;
  };
  //save button functionality
  num_locations.addEventListener("change", (e) => {
    if (parseInt(e.target.value) < parseInt(num_tablets.value)) {
      num_tablets.value = e.target.value;
    }
    if (parseInt(e.target.value) < parseInt(num_printers.value)) {
      num_printers.value = e.target.value;
    }
    render_total();
  });
  num_tablets.addEventListener("change", (e) => {
    if (parseInt(e.target.value) > parseInt(num_locations.value)) {
      e.target.value = num_locations.value;
    }
    render_total();
  });
  num_printers.addEventListener("change", (e) => {
    if (parseInt(e.target.value) > parseInt(num_locations.value)) {
      e.target.value = num_locations.value;
    }
    render_total();
  });
  num_tablets.oninput = (e) => {
    num_tablets.setCustomValidity("");
  };
  check_terms.oninput = () => {
    check_terms.setCustomValidity("");
  };
  save_btn.addEventListener("click", () => {
    let valid = true;
    [...form.elements].reverse().forEach((element) => {
      valid *= element.checkValidity();
      element.oninput = (e) => {
        e.target.setCustomValidity("");
      };
      if (!element.checkValidity()) {
        element.setCustomValidity("Please check or fill this field");
        element.reportValidity();
        return;
      }
    });
    if (valid) {
      DataCustomer.Name = edit_firstnm.value;
      DataCustomer["Last-Name"] = edit_lastnm.value;
      DataCustomer["Phone-Number"] = edit_phone.value;
      DataCustomer["Restaurant-Name"] = edit_bussnm.value;
      fillContactInf();
      fillEditConInf();
      localStorage.setItem("DataCustomer", JSON.stringify(DataCustomer));
      edit_btn.style.display = "flex";
      save_btn.style.display = "none";
      const editables = document.getElementsByClassName(
        "flow-editable-content"
      );
      editables[0].style.display = "block";
      editables[1].style.display = "none";
    }
  });
  nextbtn.addEventListener("click", (e) => {
    e.preventDefault();
    //validate non edit state
    if (save_btn.style.display === "flex") {
      save_btn.click();
    } else {
      //validate locations
      if (parseInt(num_locations.value) === 0 || num_locations.value === "") {
        num_locations.setCustomValidity(
          "Please select the number of Locations you need"
        );
        num_locations.reportValidity();
      } else {
        let valid = true;
        let formData = {};
        [...addr_form.elements].reverse().forEach((element) => {
          formData[element.name] = element.value;
          element.oninput = (e) => {
            e.target.setCustomValidity("");
          };
          valid *= element.checkValidity();
          if (!element.checkValidity()) {
            element.setCustomValidity("Please check or fill this field");
            element.reportValidity();
            return;
          }
        });
        if (shipp_check.checked) {
          [...shipp_form.elements].reverse().forEach((element) => {
            formData[element.name] = element.value;
            element.oninput = (e) => {
              e.target.setCustomValidity("");
            };
            valid *= element.checkValidity();
            if (!element.checkValidity()) {
              element.setCustomValidity("Please check or fill this field");
              element.reportValidity();
              return;
            }
          });
        } else {
          Object.keys(formData).forEach((elem) => {
            formData[elem + "S"] = formData[elem];
          });
        }
        if (valid) {
          Object.keys(formData).forEach((key) => {
            DataCustomer[key] = formData[key];
          });
          if (!check_terms.checked) {
            check_terms.setCustomValidity(
              "Accept the Terms of Service before continue to Payment"
            );
            check_terms.reportValidity();
          } else {
            const paymentKey = Date.now();
            const options = {
              checkoutToken: moonClrkDomains[window.location.host],
              width: "100%",
              amount_cents: grandTotal * 100,
              email: DataCustomer.Email,
              name: DataCustomer.Name + " " + DataCustomer["Last-Name"],
              cid: paymentKey,
            };
            const newData = {
              ...DataCustomer,
              Locations: num_locations.value,
              "Total-Tablets": num_tablets.value,
              "Total-Printers": num_printers.value,
              Addons: Addons,
              foodLogins: parseFoodLogins(),
            };
            localStorage.setItem("options", JSON.stringify(options));
            localStorage.setItem("DataCustomer", JSON.stringify(newData));
            localStorage.setItem("PaymentKey", paymentKey);
            sendToSf(newData, () => {
              location.href = "/payment-test";
            });
          }
        }
      }
    }
  });
  Object.keys(Addons).forEach((key) => {
    const addOn = Addons[key];
    const check = document.getElementById(key + "Check");
    const Row = document.getElementById(key + "Row");
    if (check) {
      check.addEventListener("change", (e) => {
        addOn.selected = e.target.checked;
        render_total();
      });
      check.checked = addOn.selected;
      if (check.checked) {
        document
          .getElementById(key + "Ui")
          .getElementsByTagName("div")[0]
          .classList.add("w--redirected-checked");
      } else {
        if (Row) {
          Row.style.display = "none";
        }
      }
    }
  });
  if (DataCustomer["Own-Tablet"]) {
    num_tablets.disabled = true;
  }
  document.getElementById("shipp-cont").style.display = "none";
  fillContactInf();
  fillEditConInf();
  render_total();
});

// Core Addons
document.addEventListener("DOMContentLoaded", () => {
  if (localStorage.getItem("Paid")) {
    location.href = "/test-area/flow/connect-ofos";
  }
  if (localStorage.getItem("DataCustomer") === null) {
    location.href = "/test-area/flow/start";
  }
  //Data & Data customer
  const DataCustomer = JSON.parse(localStorage.getItem("DataCustomer"));
  const strData = localStorage.getItem("Data");
  let Data = JSON.parse(strData);
  const next_btn = document.getElementById("next_btn");
  const currency = "$";
  //prices
  const price_per_location = parseInt(
    document
      .getElementById("price_per_location")
      .innerHTML.replace("from " + currency, ""),
    ""
  );
  const tablets = parseInt(
    document.getElementById("per_tablet").innerHTML.replace(currency, "")
  );
  const printers = parseInt(
    document.getElementById("per_printer").innerHTML.replace(currency, "")
  );
  const total = document.getElementById("step2-total2");
  //number inputs
  const num_locations = document.getElementById("Total-Locations");
  const num_tablets = document.getElementById("Total-Tablets");
  const num_printers = document.getElementById("Total-Printers");
  const checkOwnTablet = document.getElementById("Own-Tablet");
  const MoreTablets = document.getElementById("MoreTablets");
  const MorePrinters = document.getElementById("MorePrinters");
  //flags add-ins prices
  const Addons = {
    ia: {
      selected: false,
      price: 0,
      isCharged: true,
    },
    ld: {
      selected: false,
      price: 0,
      isCharged: true,
    },
    m86: {
      selected: false,
      price: 0,
      isCharged: true,
    },
    pos: {
      selected: false,
      price: 0,
      isCharged: false,
    },
    hos: {
      selected: false,
      price: 0,
      isCharged: false,
    },
    ps: {
      selected: false,
      price: 0,
      isCharged: true,
    },
  };
  //Initialize number inputs
  Data["Total-Price-Tablets"] = tablets * num_tablets.value;
  num_locations.value = parseInt(DataCustomer.Locations);
  num_tablets.value = 0;
  num_printers.value = 0;
  //Total
  render_total = () => {
    let totaln = parseInt(
      price_per_location * num_locations.value +
        tablets * num_tablets.value +
        printers * num_printers.value
    );
    Object.keys(Addons).forEach((key) => {
      const addOn = Addons[key];
      totaln += parseInt(
        addOn.selected * addOn.isCharged * addOn.price * num_locations.value
      );
    });
    total.innerHTML = "$" + totaln + ".00";
  };
  num_locations.addEventListener("change", (e) => {
    if (parseInt(e.target.value) < parseInt(num_tablets.value)) {
      num_tablets.value = e.target.value;
    }
    if (parseInt(e.target.value) < parseInt(num_printers.value)) {
      num_printers.value = e.target.value;
    }
    if (e.target.value < 4 && Addons.ps.selected) {
      document.getElementById("psCont").click();
    }
    render_total();
  });
  num_tablets.addEventListener("change", (e) => {
    if (parseInt(e.target.value) > parseInt(num_locations.value)) {
      e.target.value = num_locations.value;
    }
    render_total();
  });
  num_printers.addEventListener("change", (e) => {
    if (parseInt(e.target.value) > parseInt(num_locations.value)) {
      e.target.value = num_locations.value;
    }
    render_total();
  });
  num_tablets.oninput = (e) => {
    num_tablets.setCustomValidity("");
  };
  //Add-ons
  Object.keys(Addons).forEach((key) => {
    const addOnPrice = document.getElementById(key + "Price");
    Addons[key].price = addOnPrice
      ? parseInt(document.getElementById(key + "Price").innerHTML)
      : 0;
    const Btn = document.getElementById(key + "Btn");
    const Cont = document.getElementById(key + "Cont");
    if (Cont && Btn) {
      Cont.addEventListener("click", (e) => {
        let willChange = false;
        if (Addons[key].selected) {
          willChange = true;
        } else {
          if (key === "ps") {
            const text = Cont.getElementsByClassName(
              "flow-addon-starting-at"
            )[0];
            const min_required = 4;
            const nonValidText =
              "Please select at least " + min_required + " Locations";
            const validText = "starting at 4 locations";
            if (parseInt(num_locations.value) < min_required) {
              text.innerHTML = nonValidText;
              text.style.color = "red";
              setTimeout(() => {
                text.innerHTML = validText;
                text.style.color = "#112232";
              }, 800);
            } else {
              willChange = true;
            }
          } else {
            willChange = true;
          }
        }
        Addons[key].selected = willChange
          ? !Addons[key].selected
          : Addons[key].selected;
        console.log(Addons[key].selected);
        if (Addons[key].isCharged) {
          Btn.innerHTML = Addons[key].selected ? "Added" : "Add to cart";
        } else {
          Btn.innerHTML = Addons[key].selected ? "Requested" : "Request access";
        }
        Btn.style.backgroundColor = Addons[key].selected
          ? "#efefef"
          : "#ff5530";
        if (key === "ps") {
          setTimeout(() => {
            Cont.style.backgroundColor = Addons[key].selected
              ? "#fff !important"
              : "#f8f8f8 !important";
            Cont.style.borderColor = Addons[key].selected
              ? "rgb(255, 85, 48)"
              : "rgb(245, 245, 245)";
          }, 500);
        }
        render_total();
      });
    }
  });
  //check own tablet
  const OwntabletOrNot = () => {
    if (checkOwnTablet.checked === true) {
      num_tablets.value = 0;
      num_tablets.disabled = true;
      render_total();
    } else {
      num_tablets.disabled = false;
      render_total();
    }
  };
  checkOwnTablet.addEventListener("change", () => {
    OwntabletOrNot();
  });
  //Fill Data
  next_btn.addEventListener("click", () => {
    if (parseInt(num_tablets.value) <= 0 && !checkOwnTablet.checked) {
      num_tablets.setCustomValidity(
        "Please select at least 1 Tablet or Check 'I already have my own tablet"
      );
      num_tablets.reportValidity();
    } else {
      Data.Locations = num_locations.value;
      Data["Total-Printers"] = num_printers.value;
      Data["Total-Tablets"] = num_tablets.value;
      Data["Own-Tablet"] = checkOwnTablet.checked;
      Data["Addons"] = Addons;
      Data["Printers"] = printers; //Price
      Data["Tablets"] = tablets; //Price
      Data.MorePrinters = MorePrinters.checked;
      Data.MoreTablets = MoreTablets.checked;
      localStorage.setItem(
        "DataCustomer",
        JSON.stringify({ ...DataCustomer, ...Data })
      );
      window.location = "/test-area/flow/confirm-info-core";
    }
  });
  render_total();
});

// Core Checkout
document.addEventListener("DOMContentLoaded", () => {
  // Constants
  const currency = "$";
  const PhoneCode = "";
  const moonClrkDomains = {
    "otter-draft.webflow.io": "5f5dcnj9hoyi",
    "www.tryotter.com": "5cewnfjrkyaq",
  };
  let grandTotal = 0;
  //Contact Information
  const namep = document.getElementById("name");
  const phonep = document.getElementById("phone");
  const emailp = document.getElementById("email");
  const nameb = document.getElementById("name_buss");
  //Edit Contact Information
  const edit_firstnm = document.getElementById("Name");
  const edit_lastnm = document.getElementById("Last-Name");
  const edit_phone = document.getElementById("Phone");
  const edit_bussnm = document.getElementById("Business-Name");
  const form = document.getElementById("email-form");
  const addr_form = document.getElementById("add-form");
  const shipp_form = document.getElementById("shipp-form");
  const shipp_check = document.getElementById("shipp-check");
  //Save edited contact information
  const edit_btn = document.getElementById("edit_btn");
  const save_btn = document.getElementById("save_btn");
  //Check terms and Next button
  const check_terms = document.getElementById("term-check");
  const nextbtn = document.getElementById("next_btn");
  //Data customer
  const strCustomerData = localStorage.getItem("DataCustomer");
  const DataCustomer = JSON.parse(strCustomerData);
  const Addons = DataCustomer.Addons;
  // Prices
  const price_per_location = parseInt(
    document
      .getElementById("price_per_location")
      .innerHTML.replace(currency, ""),
    ""
  );
  const total = document.getElementById("step2-total");
  const total2 = document.getElementById("step2-total2");
  //number inputs
  const num_locations = document.getElementById("Total-Locations");
  const num_tablets = document.getElementById("Total-Tablets");
  const num_printers = document.getElementById("Total-Printers");
  // Prices
  const tablets = DataCustomer.Tablets;
  const printers = DataCustomer.Printers;
  // Products
  const products = {
    free: "BD0000013",
    essentials: "BD0000014",
    core: "BD0000016",
    pro: "BD0000015",
    Tablet: "HW0000030",
    OwnTablet: "HW0000024",
    Printer: "HW0000029",
    NoPrinter: "HW0000035",
    ia: "AD0000008",
    ld: "AD0000007",
    m86: "AD0000005;AD0000013",
    hos: "AD0000035",
    ps: "AD0000019",
  };
  // SF call
  const sendToSf = (unparsedData, action) => {
    // Getting products list
    let ProductsChosen = [products.core];
    // Get hardware
    const printerProdKey =
      parseInt(unparsedData["Total-Printers"]) == 0 ? "NoPrinter" : "Printer";
    ProductsChosen.push(products[printerProdKey]);

    if (parseInt(unparsedData["Total-Tablets"]) > 0) {
      ProductsChosen.push(products.Tablet);
    }
    if (unparsedData["Own-Tablet"]) {
      ProductsChosen.push(products.OwnTablet);
    }
    Object.keys(Addons).forEach((key) => {
      if (products[key]) {
        if (Addons[key].selected && Addons[key].isCharged) {
          ProductsChosen.push(products[key]);
        }
      }
    });
    const parsedData = {
      query: `email = '${unparsedData.Email}' AND country__c = '${unparsedData.Country}' AND (LeadSource = 'Inbound - Self Service') AND (Hubster_step__c = 'Creation' OR Hubster_step__c = 'Product_selection')`,
      "# Locations": unparsedData.Locations,
      "# Tablets": unparsedData["Total-Tablets"],
      "# Printers": unparsedData["Total-Printers"],
      Street: unparsedData.Address + " " + unparsedData.Apt,
      City: unparsedData.City,
      State: unparsedData.State,
      Zip: unparsedData["Postal-Code"],
      StreetS: unparsedData.AddressS + " " + unparsedData.AptS,
      CityS: unparsedData.CityS,
      StateS: unparsedData.StateS,
      ZipS: unparsedData["Postal-CodeS"],
      Products: ProductsChosen.join(";"),
      PosInterest: Addons.pos ? Addons.pos.selected : false,
      HandoffsInterest: Addons.hos ? Addons.hos.selected : false,
      NeedMoreTablets: unparsedData.MoreTablets,
      NeedMorePrinters: unparsedData.MorePrinters,
      LastName: unparsedData.Name + " " + unparsedData["Last-Name"],
      Company: unparsedData["Restaurant-Name"],
      "Mobile Phone": PhoneCode + unparsedData["Phone-Number"],
      ...unparsedData.foodLogins,
    };
    fetch("https://hooks.zapier.com/hooks/catch/1999765/b3serax/", {
      method: "POST",
      headers: {},
      body: JSON.stringify(parsedData),
      redirect: "follow",
    })
      .then((response) => response.json())
      .then(() => {
        action();
      })
      .catch((error) => console.log("error", error));
  };
  const foodLogins = [
    "uberEats",
    "grubHub",
    "caviar",
    "doordash",
    "postmates",
    "biteSquad",
    "chowNow",
    "waitr",
    "zuppler",
  ];
  const parseFoodLogins = () => {
    let data = {};
    const cards = document.getElementsByClassName(
      "flow-confirm-ofo-button w-inline-block"
    );
    [...cards].forEach((card, indx) => {
      if (card.style.borderColor === "rgb(255, 85, 48)") {
        data[foodLogins[indx]] = true;
      }
    });
    return data;
  };
});
document.addEventListener("DOMContentLoaded", () => {
  if (localStorage.getItem("Paid")) {
    location.href = "/test-area/flow/connect-ofos";
  }
  if (localStorage.getItem("DataCustomer") === null) {
    location.href = "/test-area/flow/start";
  }
  // Intializa inputs
  num_locations.value = parseInt(DataCustomer.Locations);
  num_tablets.value = parseInt(DataCustomer["Total-Tablets"]);
  num_printers.value = parseInt(DataCustomer["Total-Printers"]);
  //Fill contact information
  const fillContactInf = () => {
    namep.innerHTML = DataCustomer.Name + " " + DataCustomer["Last-Name"];
    phonep.innerHTML = DataCustomer["Phone-Number"];
    emailp.innerHTML = DataCustomer.Email;
    nameb.innerHTML = DataCustomer["Restaurant-Name"];
  };
  //Fill edit contact information
  const fillEditConInf = () => {
    edit_firstnm.value = DataCustomer.Name;
    edit_lastnm.value = DataCustomer["Last-Name"];
    edit_phone.value = DataCustomer["Phone-Number"];
    edit_bussnm.value = DataCustomer["Restaurant-Name"];
  };
  shipp_check.addEventListener("change", (e) => {
    const cont = document.getElementById("shipp-cont");
    cont.style.display = e.target.checked ? "block" : "none";
  });
  // render function
  render_total = () => {
    const totalTablets = parseInt(tablets * num_tablets.value);
    const totalPrinters = parseInt(printers * num_printers.value);
    let totaln = parseInt(
      price_per_location * num_locations.value + totalTablets + totalPrinters
    );
    Object.keys(Addons).forEach((key) => {
      const addOn = Addons[key];
      const totalAddon = parseInt(
        addOn.selected * addOn.isCharged * addOn.price * num_locations.value
      );
      const Row = document.getElementById(key + "Total");
      if (Row) {
        Row.innerHTML = currency + totalAddon + ".00";
        totaln += totalAddon;
      }
    });
    document.getElementById("Total-Price-Printers").innerHTML =
      currency + totalPrinters + ".00";
    document.getElementById("Total-Price-Tablets").innerHTML =
      currency + totalTablets + ".00";
    total.innerHTML = currency + totaln + ".00";
    total2.innerHTML = currency + totaln + ".00";
    grandTotal = totaln;
  };
  //save button functionality
  num_locations.addEventListener("change", (e) => {
    if (parseInt(e.target.value) < parseInt(num_tablets.value)) {
      num_tablets.value = e.target.value;
    }
    if (parseInt(e.target.value) < parseInt(num_printers.value)) {
      num_printers.value = e.target.value;
    }
    if (e.target.value < 4 && Addons.ps.selected) {
      document.getElementById("psCheck").click();
      document.getElementById("psCheck").disabled = true;
    } else {
      document.getElementById("psCheck").disabled = false;
    }
    render_total();
  });
  num_tablets.addEventListener("change", (e) => {
    if (parseInt(e.target.value) > parseInt(num_locations.value)) {
      e.target.value = num_locations.value;
    }
    render_total();
  });
  num_printers.addEventListener("change", (e) => {
    if (parseInt(e.target.value) > parseInt(num_locations.value)) {
      e.target.value = num_locations.value;
    }
    render_total();
  });
  num_tablets.oninput = (e) => {
    num_tablets.setCustomValidity("");
  };
  check_terms.oninput = () => {
    check_terms.setCustomValidity("");
  };
  save_btn.addEventListener("click", () => {
    let valid = true;
    [...form.elements].reverse().forEach((element) => {
      valid *= element.checkValidity();
      element.oninput = (e) => {
        e.target.setCustomValidity("");
      };
      if (!element.checkValidity()) {
        element.setCustomValidity("Please check or fill this field");
        element.reportValidity();
        return;
      }
    });
    if (valid) {
      DataCustomer.Name = edit_firstnm.value;
      DataCustomer["Last-Name"] = edit_lastnm.value;
      DataCustomer["Phone-Number"] = edit_phone.value;
      DataCustomer["Restaurant-Name"] = edit_bussnm.value;
      fillContactInf();
      fillEditConInf();
      localStorage.setItem("DataCustomer", JSON.stringify(DataCustomer));
      edit_btn.style.display = "flex";
      save_btn.style.display = "none";
      const editables = document.getElementsByClassName(
        "flow-editable-content"
      );
      editables[0].style.display = "block";
      editables[1].style.display = "none";
    }
  });
  nextbtn.addEventListener("click", (e) => {
    e.preventDefault();
    //validate non edit state
    if (save_btn.style.display === "flex") {
      save_btn.click();
    } else {
      //validate locations
      if (parseInt(num_locations.value) === 0 || num_locations.value === "") {
        num_locations.setCustomValidity(
          "Please select the number of Locations you need"
        );
        num_locations.reportValidity();
      } else {
        let valid = true;
        let formData = {};
        [...addr_form.elements].reverse().forEach((element) => {
          formData[element.name] = element.value;
          element.oninput = (e) => {
            e.target.setCustomValidity("");
          };
          valid *= element.checkValidity();
          if (!element.checkValidity()) {
            element.setCustomValidity("Please check or fill this field");
            element.reportValidity();
            return;
          }
        });
        if (shipp_check.checked) {
          [...shipp_form.elements].reverse().forEach((element) => {
            formData[element.name] = element.value;
            element.oninput = (e) => {
              e.target.setCustomValidity("");
            };
            valid *= element.checkValidity();
            if (!element.checkValidity()) {
              element.setCustomValidity("Please check or fill this field");
              element.reportValidity();
              return;
            }
          });
        } else {
          Object.keys(formData).forEach((elem) => {
            formData[elem + "S"] = formData[elem];
          });
        }
        if (valid) {
          Object.keys(formData).forEach((key) => {
            DataCustomer[key] = formData[key];
          });
          if (!check_terms.checked) {
            check_terms.setCustomValidity(
              "Accept the Terms of Service before continue to Payment"
            );
            check_terms.reportValidity();
          } else {
            const paymentKey = Date.now();
            const options = {
              checkoutToken: moonClrkDomains[window.location.host],
              width: "100%",
              amount_cents: grandTotal * 100,
              email: DataCustomer.Email,
              name: DataCustomer.Name + " " + DataCustomer["Last-Name"],
              cid: paymentKey,
            };
            localStorage.setItem("options", JSON.stringify(options));
            const newData = {
              ...DataCustomer,
              Locations: num_locations.value,
              "Total-Tablets": num_tablets.value,
              "Total-Printers": num_printers.value,
              Addons: Addons,
              foodLogins: parseFoodLogins(),
            };
            localStorage.setItem("DataCustomer", JSON.stringify(newData));
            localStorage.setItem("PaymentKey", paymentKey);
            sendToSf(newData, () => {
              location.href = "/payment-test";
            });
          }
        }
      }
    }
  });
  Object.keys(Addons).forEach((key) => {
    const addOn = Addons[key];
    const check = document.getElementById(key + "Check");
    const Row = document.getElementById(key + "Row");
    if (check) {
      check.addEventListener("change", (e) => {
        addOn.selected = e.target.checked;
        render_total();
      });
      check.checked = addOn.selected;
      if (check.checked) {
        document
          .getElementById(key + "Ui")
          .getElementsByTagName("div")[0]
          .classList.add("w--redirected-checked");
      } else {
        if (Row) {
          Row.style.display = "none";
        }
      }
    }
  });
  if (DataCustomer["Own-Tablet"]) {
    num_tablets.disabled = true;
  }
  document.getElementById("shipp-cont").style.display = "none";
  fillContactInf();
  fillEditConInf();
  render_total();
});

// Pro Addons
document.addEventListener("DOMContentLoaded", () => {
  if (localStorage.getItem("Paid")) {
    location.href = "/test-area/flow/connect-ofos";
  }
  if (localStorage.getItem("DataCustomer") === null) {
    location.href = "/test-area/flow/start";
  }
  //Data & Data customer
  const DataCustomer = JSON.parse(localStorage.getItem("DataCustomer"));
  const strData = localStorage.getItem("Data");
  let Data = JSON.parse(strData);
  const next_btn = document.getElementById("next_btn");
  const currency = "$";
  //prices
  const price_per_location = parseInt(
    document
      .getElementById("price_per_location")
      .innerHTML.replace(currency, ""),
    ""
  );
  const tablets = parseInt(
    document.getElementById("per_tablet").innerHTML.replace(currency, "")
  );
  const printers = parseInt(
    document.getElementById("per_printer").innerHTML.replace(currency, "")
  );
  const total = document.getElementById("step2-total2");
  //number inputs
  const num_locations = document.getElementById("Total-Locations");
  const num_tablets = document.getElementById("Total-Tablets");
  const num_printers = document.getElementById("Total-Printers");
  const checkOwnTablet = document.getElementById("Own-Tablet");
  const MoreTablets = document.getElementById("MoreTablets");
  const MorePrinters = document.getElementById("MorePrinters");
  const total_especial = document.getElementById("step2-total3");
  total_especial.innerHTML = currency + "20.00";
  //flags add-ins prices
  const Addons = {
    ia: {
      selected: false,
      price: 0,
      isCharged: true,
    },
    ld: {
      selected: false,
      price: 0,
      isCharged: true,
    },
    m86: {
      selected: false,
      price: 0,
      isCharged: true,
    },
    pos: {
      selected: false,
      price: 0,
      isCharged: false,
    },
    hos: {
      selected: false,
      price: 0,
      isCharged: false,
    },
    ps: {
      selected: false,
      price: 0,
      isCharged: true,
    },
  };
  //Initialize number inputs
  Data["Total-Price-Tablets"] = tablets * num_tablets.value;
  num_locations.value = parseInt(DataCustomer.Locations);
  num_tablets.value = 0;
  num_printers.value = 0;
  //Total
  render_total = () => {
    let totaln = parseInt(
      price_per_location * num_locations.value +
        tablets * num_tablets.value +
        printers * num_printers.value
    );
    Object.keys(Addons).forEach((key) => {
      const addOn = Addons[key];
      totaln += parseInt(
        addOn.selected * addOn.isCharged * addOn.price * num_locations.value
      );
    });
    console.log(Addons);
    total.innerHTML = "$" + totaln + ".00";
  };
  num_locations.addEventListener("change", (e) => {
    if (parseInt(e.target.value) < parseInt(num_tablets.value)) {
      num_tablets.value = e.target.value;
    }
    if (parseInt(e.target.value) < parseInt(num_printers.value)) {
      num_printers.value = e.target.value;
    }
    render_total();
  });
  num_tablets.addEventListener("change", (e) => {
    if (parseInt(e.target.value) > parseInt(num_locations.value)) {
      e.target.value = num_locations.value;
    }
    render_total();
  });
  num_printers.addEventListener("change", (e) => {
    if (parseInt(e.target.value) > parseInt(num_locations.value)) {
      e.target.value = num_locations.value;
    }
    render_total();
  });
  num_tablets.oninput = (e) => {
    num_tablets.setCustomValidity("");
  };
  //Add-ons
  Object.keys(Addons).forEach((key) => {
    const addOnPrice = document.getElementById(key + "Price");
    Addons[key].price = addOnPrice
      ? parseInt(document.getElementById(key + "Price").innerHTML)
      : 0;
    const Btn = document.getElementById(key + "Btn");
    const Cont = document.getElementById(key + "Cont");
    if (Cont && Btn) {
      Cont.addEventListener("click", () => {
        Addons[key].selected = !Addons[key].selected;
        if (Addons[key].isCharged) {
          Btn.innerHTML = Addons[key].selected ? "Added" : "Add to cart";
        } else {
          Btn.innerHTML = Addons[key].selected ? "Requested" : "Request access";
        }
        Btn.style.backgroundColor = Addons[key].selected
          ? "#efefef"
          : "#ff5530";
        Cont.style.backgroundColor = Addons[key].selected ? "#fff" : "#f8f8f8";
        render_total();
      });
    }
  });
  //check own tablet
  const OwntabletOrNot = () => {
    if (checkOwnTablet.checked === true) {
      num_tablets.value = 0;
      num_tablets.disabled = true;
      render_total();
    } else {
      num_tablets.disabled = false;
      render_total();
    }
  };
  checkOwnTablet.addEventListener("change", () => {
    OwntabletOrNot();
  });
  //Fill Data
  next_btn.addEventListener("click", () => {
    if (parseInt(num_tablets.value) <= 0 && !checkOwnTablet.checked) {
      num_tablets.setCustomValidity(
        "Please select at least 1 Tablet or Check 'I already have my own tablet"
      );
      num_tablets.reportValidity();
    } else {
      Data.Locations = num_locations.value;
      Data["Total-Printers"] = num_printers.value;
      Data["Total-Tablets"] = num_tablets.value;
      Data["Own-Tablet"] = checkOwnTablet.checked;
      Data["Addons"] = Addons;
      Data["Printers"] = printers; //Price
      Data["Tablets"] = tablets; //Price
      Data.MorePrinters = MorePrinters.checked;
      Data.MoreTablets = MoreTablets.checked;
      localStorage.setItem(
        "DataCustomer",
        JSON.stringify({ ...DataCustomer, ...Data })
      );
      window.location = "/test-area/flow/confirm-info-pro";
    }
  });
  render_total();
});

// Pro Checkout
document.addEventListener("DOMContentLoaded", () => {
  // Constants
  const currency = "$";
  const PhoneCode = "";
  const moonClrkDomains = {
    "otter-draft.webflow.io": "15zdxc8si4z0",
    "www.tryotter.com": "44nhe3ggn8ac",
  };
  let grandTotal = 0;
  //Contact Information
  const namep = document.getElementById("name");
  const phonep = document.getElementById("phone");
  const emailp = document.getElementById("email");
  const nameb = document.getElementById("name_buss");
  //Edit Contact Information
  const edit_firstnm = document.getElementById("Name");
  const edit_lastnm = document.getElementById("Last-Name");
  const edit_phone = document.getElementById("Phone");
  const edit_bussnm = document.getElementById("Business-Name");
  const form = document.getElementById("email-form");
  const addr_form = document.getElementById("add-form");
  const shipp_form = document.getElementById("shipp-form");
  const shipp_check = document.getElementById("shipp-check");
  //Save edited contact information
  const edit_btn = document.getElementById("edit_btn");
  const save_btn = document.getElementById("save_btn");
  //Check terms and Next button
  const check_terms = document.getElementById("term-check");
  const nextbtn = document.getElementById("next_btn");
  //Data customer
  const strCustomerData = localStorage.getItem("DataCustomer");
  const DataCustomer = JSON.parse(strCustomerData);
  const Addons = DataCustomer.Addons;
  // Prices
  const price_per_location = parseInt(
    document
      .getElementById("price_per_location")
      .innerHTML.replace(currency, ""),
    ""
  );
  const total = document.getElementById("step2-total");
  const total2 = document.getElementById("step2-total2");
  const total_especial = document.getElementById("step2-total3");
  //number inputs
  const num_locations = document.getElementById("Total-Locations");
  const num_tablets = document.getElementById("Total-Tablets");
  const num_printers = document.getElementById("Total-Printers");
  // Prices
  const tablets = DataCustomer.Tablets;
  const printers = DataCustomer.Printers;
  // Products
  const products = {
    free: "BD0000013",
    essentials: "BD0000014",
    core: "BD0000016",
    pro: "BD0000015",
    Tablet: "HW0000030",
    OwnTablet: "HW0000024",
    Printer: "HW0000029",
    NoPrinter: "HW0000035",
    ia: "AD0000008",
    ld: "AD0000007",
    m86: "AD0000005;AD0000013",
    hos: "AD0000035",
    ps: "AD0000021",
  };
  // SF call
  const sendToSf = (unparsedData, action) => {
    // Getting products list
    let ProductsChosen = [products.core];
    // Get hardware
    const printerProdKey =
      parseInt(unparsedData["Total-Printers"]) == 0 ? "NoPrinter" : "Printer";
    ProductsChosen.push(products[printerProdKey]);

    if (parseInt(unparsedData["Total-Tablets"]) > 0) {
      ProductsChosen.push(products.Tablet);
    }
    if (unparsedData["Own-Tablet"]) {
      ProductsChosen.push(products.OwnTablet);
    }
    Object.keys(Addons).forEach((key) => {
      if (products[key]) {
        if (Addons[key].selected && Addons[key].isCharged) {
          ProductsChosen.push(products[key]);
        }
      }
    });
    const parsedData = {
      query: `email = '${unparsedData.Email}' AND country__c = '${unparsedData.Country}' AND (LeadSource = 'Inbound - Self Service') AND (Hubster_step__c = 'Creation' OR Hubster_step__c = 'Product_selection')`,
      "# Locations": unparsedData.Locations,
      "# Tablets": unparsedData["Total-Tablets"],
      "# Printers": unparsedData["Total-Printers"],
      Street: unparsedData.Address + " " + unparsedData.Apt,
      City: unparsedData.City,
      State: unparsedData.State,
      Zip: unparsedData["Postal-Code"],
      StreetS: unparsedData.AddressS + " " + unparsedData.AptS,
      CityS: unparsedData.CityS,
      StateS: unparsedData.StateS,
      ZipS: unparsedData["Postal-CodeS"],
      Products: ProductsChosen.join(";"),
      PosInterest: Addons.pos ? Addons.pos.selected : false,
      HandoffsInterest: Addons.hos ? Addons.hos.selected : false,
      NeedMoreTablets: unparsedData.MoreTablets,
      NeedMorePrinters: unparsedData.MorePrinters,
      LastName: unparsedData.Name + " " + unparsedData["Last-Name"],
      Company: unparsedData["Restaurant-Name"],
      "Mobile Phone": PhoneCode + unparsedData["Phone-Number"],
      ...unparsedData.foodLogins,
    };
    fetch("https://hooks.zapier.com/hooks/catch/1999765/b3serax/", {
      method: "POST",
      headers: {},
      body: JSON.stringify(parsedData),
      redirect: "follow",
    })
      .then((response) => response.json())
      .then(() => {
        action();
      })
      .catch((error) => console.log("error", error));
  };
  const foodLogins = [
    "uberEats",
    "grubHub",
    "caviar",
    "doordash",
    "postmates",
    "biteSquad",
    "chowNow",
    "waitr",
    "zuppler",
  ];
  const parseFoodLogins = () => {
    let data = {};
    const cards = document.getElementsByClassName(
      "flow-confirm-ofo-button w-inline-block"
    );
    [...cards].forEach((card, indx) => {
      if (card.style.borderColor === "rgb(255, 85, 48)") {
        data[foodLogins[indx]] = true;
      }
    });
    return data;
  };
});
document.addEventListener("DOMContentLoaded", () => {
  if (localStorage.getItem("Paid")) {
    location.href = "/test-area/flow/connect-ofos";
  }
  if (localStorage.getItem("DataCustomer") === null) {
    location.href = "/test-area/flow/start";
  }
  // Intializa inputs
  num_locations.value = parseInt(DataCustomer.Locations);
  num_tablets.value = parseInt(DataCustomer["Total-Tablets"]);
  num_printers.value = parseInt(DataCustomer["Total-Printers"]);
  //Fill contact information
  const fillContactInf = () => {
    namep.innerHTML = DataCustomer.Name + " " + DataCustomer["Last-Name"];
    phonep.innerHTML = DataCustomer["Phone-Number"];
    emailp.innerHTML = DataCustomer.Email;
    nameb.innerHTML = DataCustomer["Restaurant-Name"];
  };
  //Fill edit contact information
  const fillEditConInf = () => {
    edit_firstnm.value = DataCustomer.Name;
    edit_lastnm.value = DataCustomer["Last-Name"];
    edit_phone.value = DataCustomer["Phone-Number"];
    edit_bussnm.value = DataCustomer["Restaurant-Name"];
  };
  shipp_check.addEventListener("change", (e) => {
    const cont = document.getElementById("shipp-cont");
    cont.style.display = e.target.checked ? "block" : "none";
  });
  // render function
  render_total = () => {
    const totalTablets = parseInt(tablets * num_tablets.value);
    const totalPrinters = parseInt(printers * num_printers.value);
    let totaln = parseInt(
      price_per_location * num_locations.value + totalTablets + totalPrinters
    );
    Object.keys(Addons).forEach((key) => {
      const addOn = Addons[key];
      const totalAddon = parseInt(
        addOn.selected * addOn.isCharged * addOn.price * num_locations.value
      );
      const Row = document.getElementById(key + "Total");
      if (Row) {
        Row.innerHTML = currency + totalAddon + ".00";
        totaln += totalAddon;
      }
    });
    document.getElementById("Total-Price-Printers").innerHTML =
      currency + totalPrinters + ".00";
    document.getElementById("Total-Price-Tablets").innerHTML =
      currency + totalTablets + ".00";
    total.innerHTML = currency + totaln + ".00";
    total2.innerHTML = currency + totaln + ".00";
    grandTotal = totaln;
    total_especial.innerHTML = currency + "20.00";
  };
  //save button functionality
  num_locations.addEventListener("change", (e) => {
    if (parseInt(e.target.value) < parseInt(num_tablets.value)) {
      num_tablets.value = e.target.value;
    }
    if (parseInt(e.target.value) < parseInt(num_printers.value)) {
      num_printers.value = e.target.value;
    }
    render_total();
  });
  num_tablets.addEventListener("change", (e) => {
    if (parseInt(e.target.value) > parseInt(num_locations.value)) {
      e.target.value = num_locations.value;
    }
    render_total();
  });
  num_printers.addEventListener("change", (e) => {
    if (parseInt(e.target.value) > parseInt(num_locations.value)) {
      e.target.value = num_locations.value;
    }
    render_total();
  });
  num_tablets.oninput = (e) => {
    num_tablets.setCustomValidity("");
  };
  check_terms.oninput = () => {
    check_terms.setCustomValidity("");
  };
  save_btn.addEventListener("click", () => {
    let valid = true;
    [...form.elements].reverse().forEach((element) => {
      valid *= element.checkValidity();
      element.oninput = (e) => {
        e.target.setCustomValidity("");
      };
      if (!element.checkValidity()) {
        element.setCustomValidity("Please check or fill this field");
        element.reportValidity();
        return;
      }
    });
    if (valid) {
      DataCustomer.Name = edit_firstnm.value;
      DataCustomer["Last-Name"] = edit_lastnm.value;
      DataCustomer["Phone-Number"] = edit_phone.value;
      DataCustomer["Restaurant-Name"] = edit_bussnm.value;
      fillContactInf();
      fillEditConInf();
      localStorage.setItem("DataCustomer", JSON.stringify(DataCustomer));
      edit_btn.style.display = "flex";
      save_btn.style.display = "none";
      const editables = document.getElementsByClassName(
        "flow-editable-content"
      );
      editables[0].style.display = "block";
      editables[1].style.display = "none";
    }
  });
  nextbtn.addEventListener("click", (e) => {
    e.preventDefault();
    //validate non edit state
    if (save_btn.style.display === "flex") {
      save_btn.click();
    } else {
      //validate locations
      if (parseInt(num_locations.value) === 0 || num_locations.value === "") {
        num_locations.setCustomValidity(
          "Please select the number of Locations you need"
        );
        num_locations.reportValidity();
      } else {
        let valid = true;
        let formData = {};
        [...addr_form.elements].reverse().forEach((element) => {
          formData[element.name] = element.value;
          element.oninput = (e) => {
            e.target.setCustomValidity("");
          };
          valid *= element.checkValidity();
          if (!element.checkValidity()) {
            element.setCustomValidity("Please check or fill this field");
            element.reportValidity();
            return;
          }
        });
        if (shipp_check.checked) {
          [...shipp_form.elements].reverse().forEach((element) => {
            formData[element.name] = element.value;
            element.oninput = (e) => {
              e.target.setCustomValidity("");
            };
            valid *= element.checkValidity();
            if (!element.checkValidity()) {
              element.setCustomValidity("Please check or fill this field");
              element.reportValidity();
              return;
            }
          });
        } else {
          Object.keys(formData).forEach((elem) => {
            formData[elem + "S"] = formData[elem];
          });
        }
        if (valid) {
          Object.keys(formData).forEach((key) => {
            DataCustomer[key] = formData[key];
          });
          if (!check_terms.checked) {
            check_terms.setCustomValidity(
              "Accept the Terms of Service before continue to Payment"
            );
            check_terms.reportValidity();
          } else {
            const paymentKey = Date.now();
            const options = {
              checkoutToken: moonClrkDomains[window.location.host],
              width: "100%",
              amount_cents: grandTotal * 100,
              email: DataCustomer.Email,
              name: DataCustomer.Name + " " + DataCustomer["Last-Name"],
              cid: paymentKey,
            };
            localStorage.setItem("options", JSON.stringify(options));
            const newData = {
              ...DataCustomer,
              Locations: num_locations.value,
              "Total-Tablets": num_tablets.value,
              "Total-Printers": num_printers.value,
              Addons: Addons,
              foodLogins: parseFoodLogins(),
            };
            localStorage.setItem("DataCustomer", JSON.stringify(newData));
            localStorage.setItem("PaymentKey", paymentKey);
            sendToSf(newData, () => {
              location.href = "/payment-test";
            });
          }
        }
      }
    }
  });
  Object.keys(Addons).forEach((key) => {
    const addOn = Addons[key];
    const check = document.getElementById(key + "Check");
    const Row = document.getElementById(key + "Row");
    if (check) {
      check.addEventListener("change", (e) => {
        addOn.selected = e.target.checked;
        render_total();
      });
      check.checked = addOn.selected;
      if (check.checked) {
        document
          .getElementById(key + "Ui")
          .getElementsByTagName("div")[0]
          .classList.add("w--redirected-checked");
      } else {
        if (Row) {
          Row.style.display = "none";
        }
      }
    }
  });
  if (DataCustomer["Own-Tablet"]) {
    num_tablets.disabled = true;
  }
  document.getElementById("shipp-cont").style.display = "none";
  fillContactInf();
  fillEditConInf();
  render_total();
});

// Payment
document.addEventListener("DOMContentLoaded", () => {
  const firstPage = "/test-area/flow/start";
  const PaymentKey = localStorage.getItem("PaymentKey");
  if (PaymentKey === null && !localStorage.getItem("Paid")) {
    location.href = firstPage;
  }
  const loginsConnected = localStorage.getItem("loginsConnected")
    ? JSON.parse(localStorage.getItem("loginsConnected"))
    : [];
  localStorage.setItem("loginsConnected", JSON.stringify(loginsConnected));
  const strCustomerData = localStorage.getItem("DataCustomer");
  const DataCustomer = JSON.parse(strCustomerData);
  const countryCode = "US";
  const urlParams = new URLSearchParams(window.location.search);
  const paymentReceived = urlParams.get("custom_id") === PaymentKey;
  const paymentId = urlParams.get("customer_id");
  const sendToSf = (unparsedData, action = () => {}) => {
    const parsedData = {
      query: `email = '${unparsedData.Email}' AND country__c = '${unparsedData.Country}' AND LeadSource = 'Inbound - Self Service' AND Hubster_step__c = 'Product_Selection'`,
      PaymentID: paymentId,
      PaymentReceived: paymentReceived,
    };
    if (paymentReceived && paymentId) {
      localStorage.setItem("customer_id", paymentId);
      fetch("https://hooks.zapier.com/hooks/catch/1999765/b3ser87/", {
        method: "POST",
        headers: {},
        body: JSON.stringify(parsedData),
        redirect: "follow",
      })
        .then((response) => response.json())
        .then(() => {
          action();
        })
        .catch((error) => console.log("error", error));
    }
  };

  sendToSf(DataCustomer, () => {
    localStorage.removeItem("PaymentKey");
    localStorage.setItem("Paid", true);
    localStorage.clear();
    location.href = `https://manager-staging.tryotter.com/sign-up/?email=${DataCustomer.Email}&country=${DataCustomer.Country}&phone=${DataCustomer["Phone-Number"]}&name=${DataCustomer.Name}%20${DataCustomer["Last-Name"]}&restaurantName=${DataCustomer["Restaurant-Name"]}`;
  });
});

// Credentials (UNUSED)
document.addEventListener("DOMContentLoaded", () => {
  const firstPage = "/test-area/flow/start";
  const PaymentKey = localStorage.getItem("PaymentKey");
  if (PaymentKey === null && !localStorage.getItem("Paid")) {
    location.href = firstPage;
  }
  const loginsConnected = localStorage.getItem("loginsConnected")
    ? JSON.parse(localStorage.getItem("loginsConnected"))
    : [];
  localStorage.setItem("loginsConnected", JSON.stringify(loginsConnected));
  const strCustomerData = localStorage.getItem("DataCustomer");
  const DataCustomer = JSON.parse(strCustomerData);
  const countryCode = "US";
  const urlParams = new URLSearchParams(window.location.search);
  const paymentReceived = urlParams.get("custom_id") === PaymentKey;
  const paymentId = urlParams.get("customer_id");
  const nextBtn = document.getElementById("nextBtn");
  const loginsBtns = document.getElementsByClassName(
    "flow-modal-next w-button"
  );
  const loginsModals = document.getElementsByClassName("flow-modal-overlay");
  const loginsCards = document.getElementsByClassName("w-dyn-item");
  const openBtns = document.getElementsByClassName(
    "flow-integration-connect w-button"
  );
  const sendToSf = (unparsedData, action = () => {}) => {
    const parsedData = {
      query: `email = '${unparsedData.Email}' AND country__c = '${unparsedData.Country}' AND LeadSource = 'Inbound - Self Service' AND Hubster_step__c = 'Product_Selection'`,
      PaymentID: paymentId,
      PaymentReceived: paymentReceived,
    };
    if (paymentReceived && paymentId) {
      localStorage.setItem("customer_id", paymentId);
      fetch("https://hooks.zapier.com/hooks/catch/1999765/b3ser87/", {
        method: "POST",
        headers: {},
        body: JSON.stringify(parsedData),
        redirect: "follow",
      })
        .then((response) => response.json())
        .then(() => {
          action();
        })
        .catch((error) => console.log("error", error));
    }
  };
  const sendToSfClosed = (unparsedData, DataCustomer, action) => {
    const parsedData = {
      ...unparsedData,
      query: `email = '${DataCustomer.Email}' AND country__c = '${DataCustomer.Country}' AND LeadSource = 'Inbound - Self Service' AND (Hubster_step__c = 'Payment_Received' OR Hubster_step__c = 'Credentials_received')`,
    };
    fetch("https://hooks.zapier.com/hooks/catch/1999765/b3se5kp/", {
      method: "POST",
      headers: {},
      body: JSON.stringify(parsedData),
      redirect: "follow",
    })
      .then((response) => response.json())
      .then(() => {
        action();
      })
      .catch((error) => console.log("error", error));
  };
  const foodLogins = {
    uberEats: {
      email: "",
      pass: "",
      notSend: "",
      notSend2: "",
      pin: "",
    },
    grubHub: {
      email: "",
      pass: "",
    },
    caviar: {
      email: "",
      pass: "",
    },
    doordash: {
      email: "",
      pass: "",
      tabEmail: "",
      tabPass: "",
    },
    postmates: {
      email: "",
      pass: "",
    },
    biteSquad: {
      email: "",
      pass: "",
    },
    chowNow: {
      email: "",
      pass: "",
    },
    waitr: {
      email: "",
      pass: "",
    },
    zuppler: {
      email: "",
      pass: "",
    },
  };
  const foodLoginsKeys = Object.keys(foodLogins);
  const ERROR_MESSAGE = "Please fill this field with a correct value";

  const lockButton = (el) => {
    el.innerHTML = "Connected";
    el.style.pointerEvents = "none";
    el.style.backgroundColor = "#ff5530";
    el.style.borderColor = "#ff5530";
    el.style.color = "#fff";
  };

  let current = "";

  [...loginsCards].forEach((item, indx) => {
    const openLoginBtn = item.getElementsByClassName(
      "flow-integration-connect w-button"
    )[0];
    if (openLoginBtn) {
      openLoginBtn.addEventListener("click", () => {
        current = foodLoginsKeys[indx];
      });
      if (loginsConnected.includes(foodLoginsKeys[indx])) {
        lockButton(openLoginBtn);
      }
    }
  });

  [...loginsBtns].forEach((lBtn, indx) => {
    lBtn.addEventListener("click", () => {
      const loginsKeys = Object.keys(foodLogins[current]);
      const lForm = loginsModals[indx].getElementsByTagName("form")[0];
      let valid = 1;
      [...lForm.elements].forEach((element, indx2) => {
        element.oninput = (e) => {
          e.target.setCustomValidity("");
        };
        if (indx2 < loginsKeys.length) {
          if (!element.checkValidity()) {
            if (
              loginsKeys[indx2] !== "notSend" &&
              loginsKeys[indx2] !== "notSend2"
            ) {
              valid = 0;
              element.setCustomValidity(ERROR_MESSAGE);
              element.reportValidity();
            }
          } else {
            foodLogins[current][loginsKeys[indx2]] = element.value;
          }
          if (!valid) {
            return;
          }
        }
      });
      if (valid) {
        let zapData = {};
        Object.keys(foodLogins[current]).forEach((key) => {
          zapData[current + key] = foodLogins[current][key];
        });
        sendToSfClosed(zapData, DataCustomer, () => {
          loginsConnected.push(current);
          localStorage.setItem(
            "loginsConnected",
            JSON.stringify(loginsConnected)
          );
          loginsModals[indx].style.display = "none";
          lockButton(openBtns[indx]);
        });
      }
    });
  });

  nextBtn.addEventListener("click", (e) => {
    e.preventDefault();
    if (loginsConnected.length === 0) {
      alert(
        "Please add your login information to at least one delivery partner "
      );
    } else {
      localStorage.clear();
      window.location = "/test-area/flow/demo-video";
    }
  });
  sendToSf(DataCustomer, () => {
    localStorage.removeItem("PaymentKey");
    localStorage.setItem("Paid", true);
  });
});
