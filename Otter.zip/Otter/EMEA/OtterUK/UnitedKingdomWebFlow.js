/* ASSISTED EXTRA SCRIPT*/
document.addEventListener("DOMContentLoaded", () => {
  [...document.getElementsByClassName("button-flow-select-product")].forEach((btn)=>{
    btn.addEventListener("click", () =>{
      localStorage.setItem("DataCustomer", JSON.stringify({
        Name:"-",
        Locations: 1,
        LastName:"-",
        Country:"United Kingdom",
        Phone:"-",
        Restaurant: "-",
        Email: "-",
      }));
    })
  })
});

//*************** START SCRIPT ***************//
document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("email-form");
  const Data = {};
  const country = "United Kingdom";
  const productsPage = "/checkout/choose-product";
  const getUrlParam = (name, url = window.location.href) => {
    name = name.replace(/[\[\]]/g, "\\$&");
    var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
      results = regex.exec(url);
    if (!results) return "";
    if (!results[2]) return "";
    return decodeURIComponent(results[2].replace(/\+/g, " "));
  };
  const sendToSf = (unparsedData, action) => {
    const parsedData = {
      "Lead Country": unparsedData.Country,
      LastName: unparsedData.Name + " " + unparsedData.LastName,
      Company: unparsedData.Restaurant,
      Email: unparsedData.Email,
      "Mobile Phone": PhoneCode + unparsedData.Phone,
      Role: unparsedData.Role,
      "# Locations": unparsedData.Locations,
      utm_source: getUrlParam("utm_source").replace("{", "").replace("}", ""),
      utm_medium: getUrlParam("utm_medium").replace("{", "").replace("}", ""),
      utm_campaign: getUrlParam("utm_campaign")
        .replace("{", "")
        .replace("}", ""),
      utm_term: getUrlParam("utm_term").replace("{", "").replace("}", ""),
      utm_content: getUrlParam("utm_content").replace("{", "").replace("}", ""),
    };
    fetch("https://hooks.zapier.com/hooks/catch/1999765/b2vchyb/", {
      method: "POST",
      headers: {},
      body: JSON.stringify(parsedData),
      redirect: "follow",
    })
      .then((response) => response.json())
      .then(() => {
        action();
      })
      .catch((error) => console.log("error", error));
  };
  function formatPhoneNumber(phoneNumberString) {
    var cleaned = ("" + phoneNumberString).replace(/\D/g, "");
    var match = cleaned.match(/^(\d{3})(\d{3})(\d{4})$/);
    if (match) {
      return "(" + match[1] + ") " + match[2] + "-" + match[3];
    }
    return null;
  }
  document.getElementById("Phone").addEventListener("keypress", (e) => {
    if (e.target.value.length === 10) {
      e.target.value = formatPhoneNumber(e.target.value);
    }
  });
  form.addEventListener("submit", (e) => {
    e.preventDefault();
    localStorage.removeItem("DataCustomer");
    const formData = new FormData(e.target);
    for (var key of formData.keys()) {
      Data[key] = formData.get(key);
    }
    Data["Country"] = country;
    localStorage.setItem("DataCustomer", JSON.stringify(Data));
    sendToSf(Data, () => (location.href = productsPage));
  });
});

//*************** ANALYTICS CONFIRM SCRIPT ***************//
document.addEventListener("DOMContentLoaded", () => {
  if (localStorage.getItem("Paid")) location.href = "/activate";
  if (localStorage.getItem("DataCustomer") === null) {
    location.href = "/checkout/signup";
  }
  // Set vars and functions
  let grandTotal = 0;
  const DataCustomer = JSON.parse(localStorage.getItem("DataCustomer"));
  const DataAddress = {};
  const currency = "£";
  const sepCents = ".";
  const sepThousands = ",";
  const numberCents = sepCents + "00";
  const tax = 0.2;
  const PhoneCode = "+44";
  const editBtn = document.getElementById("editBtn");
  const nextBtn = document.getElementById("nextBtn");
  const saveBtn = document.getElementById("saveBtn");
  const total = document.getElementById("total");
  const total2 = document.getElementById("total2");
  const totalPrice = document.getElementById("totalPrice");
  const totalTax = document.getElementById("totalTax");
  const locations = document.getElementById("locations");
  const emailForm = document.getElementById("email-form");
  const addressForm = document.getElementById("addressForm");
  const termsCheck = document.getElementById("termsService");
  const moonClrkDomains = {
    "otter-uk.webflow.io": "7bi82h0v5y84",
    "www.tryotter.uk": "xr8wzpmpsnp",
  };
  const price = parseInt(
    document
      .getElementById("price")
      .innerHTML.replace(currency, "")
      .replace(sepThousands, "")
  );
  const numberWithFormat = (number) => {
    return (
      currency +
      number
        .toFixed(2)
        .toString()
        .replace(/\B(?=(\d{3})+(?!\d))/g, sepThousands)
    );
  };
  const renderTotal = () => {
    const amount = parseInt(locations.value * price);
    const amountTax = amount * tax;
    grandTotal = amount + amountTax;
    totalPrice.innerHTML = numberWithFormat(amount);
    totalTax.innerHTML = numberWithFormat(amountTax);
    total.innerHTML = numberWithFormat(grandTotal);
    total2.innerHTML = numberWithFormat(grandTotal);
  };
  const renderCustomerData = (read) => {
    Object.keys(DataCustomer).forEach((key) => {
      if (read) {
        const el = document.getElementById(key + "R");
        if (el) {
          if (key === "Name") {
            el.innerHTML = DataCustomer[key] + " " + DataCustomer["LastName"];
          } else {
            el.innerHTML = DataCustomer[key];
          }
        }
      } else {
        const el = document.getElementById(key + "-2");
        if (el) {
          el.value = DataCustomer[key];
        }
      }
    });
  };
  // Products
  const products = {
    analytics: "BD0000018",
    lite: "BD0000017",
    pro: "BD0000015",
    expert: "BD0000021",
    Tablet: "HW0000030",
    OwnTablet: "HW0000024",
    Printer: "HW0000029",
    NoPrinter: "HW0000035",
    mm: "AD0000005;AD0000013",
  };
  // SF call
  const sendToSf = (unparsedData, action) => {
    // Getting products list
    let ProductsChosen = [products.analytics];
    // Get hardware
    ProductsChosen.push(products["NoPrinter"]);
    const parsedData = {
      query: `email = '${unparsedData.Email}' AND country__c = '${unparsedData.Country}' AND (LeadSource = 'Inbound - Self Service') AND (Hubster_step__c = 'Creation' OR Hubster_step__c = 'Product_selection')`,
      "# Locations": unparsedData.Locations,
      "# Tablets": unparsedData.tablets,
      "# Printers": unparsedData.printers,
      Street: unparsedData.Address + " " + unparsedData.Apt,
      City: unparsedData.City,
      State: unparsedData.State,
      Zip: unparsedData["Postal-Code"],
      Products: ProductsChosen.join(";"),
      LastName: unparsedData.Name + " " + unparsedData.LastName,
      Company: unparsedData.Restaurant,
      "Mobile Phone": PhoneCode + unparsedData.Phone,
    };
    fetch("https://hooks.zapier.com/hooks/catch/1999765/b2vch1d/", {
      method: "POST",
      headers: {},
      body: JSON.stringify(parsedData),
      redirect: "follow",
    })
      .then((response) => response.json())
      .then(() => {
        action();
      })
      .catch((error) => console.log("error", error));
  };
  // Start with logic
  termsCheck.onchange = (e) => {
    e.target.setCustomValidity("");
  };
  locations.addEventListener("change", () => {
    renderTotal();
  });
  locations.oninput = (e) => {
    e.target.setCustomValidity("");
  };
  editBtn.addEventListener("click", () => {
    renderCustomerData(false);
  });
  saveBtn.addEventListener("click", (e) => {
    e.preventDefault();
    let formData = {};
    let valid = true;
    [...emailForm.elements].reverse().forEach((element) => {
      valid *= element.checkValidity();
      element.oninput = (e) => {
        e.target.setCustomValidity("");
      };
      formData[element.name] = element.value;
      if (!element.checkValidity()) {
        element.setCustomValidity("Please check or fill this field");
        element.reportValidity();
        return;
      }
    });
    if (valid) {
      Object.keys(formData).forEach((key) => {
        DataCustomer[key] = formData[key];
      });
      renderCustomerData(true);
      localStorage.setItem("DataCustomer", JSON.stringify(DataCustomer));
      saveBtn.style.display = "none";
      editBtn.style.display = "flex";
      document.getElementById("nonEditable").style.display = "block";
      document.getElementById("editable").style.display = "none";
    }
  });
  nextBtn.addEventListener("click", (e) => {
    e.preventDefault();
    let formData = {};
    //validate non edit state
    if (saveBtn.style.display === "flex") {
      saveBtn.click();
    }
    if (saveBtn.style.display !== "flex") {
      //validate locations
      if (parseInt(locations.value) === 0 || locations.value === "") {
        locations.setCustomValidity(
          "Please select the number of Locations you need"
        );
        locations.reportValidity();
      } else {
        //validate address form
        let valid = true;
        [...addressForm.elements].reverse().forEach((element) => {
          valid *= element.checkValidity();
          element.oninput = (e) => {
            e.target.setCustomValidity("");
          };
          formData[element.name] = element.value;
          if (!element.checkValidity()) {
            element.setCustomValidity("Please check or fill this field");
            element.reportValidity();
            return;
          }
        });
        if (valid) {
          //validate terms of service
          if (termsCheck.checked) {
            const paymentKey = Date.now();
            const options = {
              checkoutToken: moonClrkDomains[window.location.host],
              width: "100%",
              amount_cents: grandTotal * 100,
              email: DataCustomer.Email,
              name: DataCustomer.Name + " " + DataCustomer.LastName,
              cid: paymentKey,
            };
            const newData = {
              ...DataCustomer,
              ...DataAddress,
              Locations: locations.value,
            };
            localStorage.setItem("options", JSON.stringify(options));
            localStorage.setItem("DataCustomer", JSON.stringify(newData));
            localStorage.setItem("PaymentKey", paymentKey);
            sendToSf(newData, () => {
              location.href = "/payment";
            });
          } else {
            termsCheck.setCustomValidity(
              "Accept the Terms of Service before continue to Payment"
            );
            termsCheck.reportValidity();
          }
        }
      }
    }
  });
  // Initial Values
  locations.value = DataCustomer.Locations;
  renderCustomerData(true);
  renderTotal();
});

//*************** LITE ADDONS SCRIPT ***************//
document.addEventListener("DOMContentLoaded", () => {
  if (localStorage.getItem("Paid")) location.href = "/activate";
  if (localStorage.getItem("DataCustomer") === null) {
    location.href = "/checkout/signup";
  }
  // Set vars and functions
  const DataCustomer = JSON.parse(localStorage.getItem("DataCustomer"));
  const currency = "£";
  const sepCents = ".";
  const sepThousands = ",";
  const numberCents = sepCents + "00";
  const nextBtn = document.getElementById("nextBtn");
  const total = document.getElementById("total");
  const locations = document.getElementById("locations");
  const price = parseInt(
    document.getElementById("price").innerHTML.replace(currency, "")
  );
  const tablets = document.getElementById("tablets");
  const tabletsPrice = parseInt(
    document.getElementById("tabletsPrice").innerHTML.replace(currency, "")
  );
  const printers = document.getElementById("printers");
  const printersPrice = parseInt(
    document.getElementById("printersPrice").innerHTML.replace(currency, "")
  );
  const ownTablet = document.getElementById("ownTablet");
  const addOns = {
    vb: {
      selected: false,
      price: 0,
      name: "",
      number: 0,
    },
    cc: {
      selected: false,
      price: 0,
      name: "",
    },
    analytics: {
      selected: false,
      price: 0,
      name: "",
    },
    mm: {
      selected: false,
      price: 0,
      name: "",
    },
    car: {
      selected: false,
      price: 0,
      name: "",
    },
  };
  const numberWithFormat = (number) => {
    return (
      currency +
      number.toString().replace(/\B(?=(\d{3})+(?!\d))/g, sepThousands) +
      numberCents
    );
  };
  const renderTotal = () => {
    let amount = parseInt(
      locations.value * price +
        tablets.value * tabletsPrice +
        printers.value * printersPrice
    );
    Object.keys(addOns).forEach((key) => {
      const addon = addOns[key];
      if (key === "vb") {
        amount +=
          addon.selected *
          parseInt(addon.price * addon.number * locations.value);
      } else {
        amount += addon.selected * parseInt(addon.price * locations.value);
      }
    });
    total.innerHTML = numberWithFormat(amount);
  };
  // Initialize Custom Validity
  locations.oninput = (e) => {
    e.target.setCustomValidity("");
  };
  printers.oninput = (e) => {
    e.target.setCustomValidity("");
  };
  tablets.oninput = (e) => {
    e.target.setCustomValidity("");
  };
  // Set listeners
  locations.addEventListener("change", (e) => {
    if (parseInt(e.target.value) < parseInt(tablets.value)) {
      tablets.value = e.target.value;
    }
    if (parseInt(e.target.value) < parseInt(printers.value)) {
      printers.value = e.target.value;
    }
    renderTotal();
  });
  printers.addEventListener("change", (e) => {
    if (parseInt(e.target.value) > parseInt(locations.value)) {
      e.target.value = locations.value;
    }
    renderTotal();
  });
  tablets.addEventListener("change", (e) => {
    if (parseInt(e.target.value) > parseInt(locations.value)) {
      e.target.value = locations.value;
    }
    renderTotal();
  });
  ownTablet.addEventListener("click", (e) => {
    if (e.currentTarget.checked) {
      tablets.value = 0;
      tablets.disabled = true;
    } else {
      tablets.disabled = false;
    }
    renderTotal();
  });
  nextBtn.addEventListener("click", (e) => {
    e.preventDefault();
    let valid = true;
    if (locations.value <= 0) {
      valid = false;
      locations.setCustomValidity(
        "Please select the number of Locations you need"
      );
      locations.reportValidity();
    } else if (
      (tablets.value <= 0 || tablets.value === "") &&
      !ownTablet.checked
    ) {
      valid = false;
      tablets.setCustomValidity(
        "Please select at least 1 Tablet or Check 'I already have my own tablet"
      );
      tablets.reportValidity();
    }
    if (valid) {
      localStorage.setItem(
        "DataCustomer",
        JSON.stringify({
          ...DataCustomer,
          Locations: locations.value,
          Printers: printers.value,
          PrintersPrice: printersPrice,
          Tablets: tablets.value,
          TabletsPrice: tabletsPrice,
          OwnTablet: ownTablet.checked,
          addOns,
        })
      );
      location.href = "/checkout/confirm-info-lite";
    }
  });
  // Set listeners to Add Ons
  Object.keys(addOns).forEach((key) => {
    addOns[key].name = document.getElementById(key + "Name").innerHTML;
    addOns[key].price = parseInt(
      document.getElementById(key + "Price").innerHTML.replace(currency, "")
    );
    if (key === "vb") {
      const element = document.getElementById(key + "Number");
      element.oninput = (e) => {
        e.target.setCustomValidity("");
      };
      element.addEventListener("change", (e) => {
        addOns[key].number = e.target.value;
        renderTotal();
      });
      document.getElementById(key + "Add").addEventListener("click", () => {
        const number = parseInt(element.value);
        if (number <= 0 || isNaN(number)) {
          element.setCustomValidity(
            "Please select at least 1 Virtual Brand to add to cart"
          );
          element.reportValidity();
        } else {
          addOns[key].selected = true;
          addOns[key].number = number;
          document.getElementById(key + "Add").style.display = "none";
          document.getElementById(key + "Added").style.display = "flex";
          document.getElementById(key + "Btn").style.backgroundColor =
            "rgb(255, 255, 255)";
          document.getElementById(key + "Btn").style.borderColor =
            "rgb(255, 85, 48)";
        }
        renderTotal();
      });
      document.getElementById(key + "Added").addEventListener("click", (e) => {
        addOns[key].selected = false;
        document.getElementById(key + "Add").style.display = "flex";
        document.getElementById(key + "Added").style.display = "none";
        document.getElementById(key + "Btn").style.backgroundColor =
          "rgb(245, 245, 245)";
        document.getElementById(key + "Btn").style.borderColor =
          "rgb(245, 245, 245)";
        renderTotal();
      });
    } else {
      document.getElementById(key + "Btn").addEventListener("click", () => {
        if (document.getElementById(key + "Added").style.display !== "flex") {
          addOns[key].selected = true;
        } else {
          addOns[key].selected = false;
        }
        renderTotal();
      });
    }
  });
  // Initialize input number to make life easier and first render
  locations.value = DataCustomer.Locations;
  printers.value = 0;
  tablets.value = 0;
  renderTotal();
});

//*************** LITE CONFIRM SCRIPT ***************//
document.addEventListener("DOMContentLoaded", () => {
  if (localStorage.getItem("Paid")) location.href = "/activate";
  if (localStorage.getItem("DataCustomer") === null) {
    location.href = "/checkout/signup";
  }
  // Set vars and functions
  let grandTotal = 0;
  const DataCustomer = JSON.parse(localStorage.getItem("DataCustomer"));
  const DataAddress = {};
  const currency = "£";
  const sepCents = ".";
  const sepThousands = ",";
  const tax = 0.2;
  const editBtn = document.getElementById("editBtn");
  const nextBtn = document.getElementById("nextBtn");
  const saveBtn = document.getElementById("saveBtn");
  const total = document.getElementById("total");
  const total2 = document.getElementById("total2");
  const totalPrice = document.getElementById("totalPrice");
  const totalTax = document.getElementById("totalTax");
  const locations = document.getElementById("locations");
  const printers = document.getElementById("printers");
  const printersTotal = document.getElementById("printersTotal");
  const tablets = document.getElementById("tablets");
  const tabletsTotal = document.getElementById("tabletsTotal");
  const emailForm = document.getElementById("email-form");
  const addressForm = document.getElementById("addressForm");
  const termsCheck = document.getElementById("termsService");
  const moonClrkDomains = {
    "otter-uk.webflow.io": "7bi82h0v5y84",
    "www.tryotter.uk": "xr8wzpmpsnp",
  };
  const price = parseInt(
    document
      .getElementById("price")
      .innerHTML.replace(currency, "")
      .replace(sepThousands, "")
  );
  const numberWithFormat = (number) => {
    return (
      currency +
      number
        .toFixed(2)
        .toString()
        .replace(/\B(?=(\d{3})+(?!\d))/g, sepThousands)
    );
  };
  const renderTotal = () => {
    const amountLocations = parseInt(locations.value * price);
    const amountPrinters = parseInt(
      printers.value * DataCustomer.PrintersPrice
    );
    const amountTablets = parseInt(tablets.value * DataCustomer.TabletsPrice);
    const amountVb = parseInt(
      DataCustomer.addOns.vb.selected
        ? DataCustomer.addOns.vb.price *
            document.getElementById("vbNumber").value *
            locations.value
        : 0
    );
    let amount = amountLocations + amountPrinters + amountTablets + amountVb;
    Object.keys(DataCustomer.addOns).forEach((key) => {
      const addon = DataCustomer.addOns[key];
      if (key !== "vb") {
        const addonPrice = addon.selected * (addon.price * locations.value);
        document.getElementById(key + "Total").innerHTML =
          numberWithFormat(addonPrice);
        amount += addonPrice;
      }
    });
    const amountTax = amount * tax;
    grandTotal = amount + amountTax;
    totalPrice.innerHTML = numberWithFormat(amount);
    printersTotal.innerHTML = numberWithFormat(amountPrinters);
    tabletsTotal.innerHTML = numberWithFormat(amountTablets);
    totalTax.innerHTML = numberWithFormat(amountTax);
    total.innerHTML = numberWithFormat(grandTotal);
    total2.innerHTML = numberWithFormat(grandTotal);
    if (DataCustomer.addOns.vb.selected) {
      document.getElementById("vbTotal").innerHTML = numberWithFormat(amountVb);
    }
  };
  const renderCustomerData = (read) => {
    Object.keys(DataCustomer).forEach((key) => {
      if (read) {
        const el = document.getElementById(key + "R");
        if (el) {
          if (key === "Name") {
            el.innerHTML = DataCustomer[key] + " " + DataCustomer["LastName"];
          } else {
            el.innerHTML = DataCustomer[key];
          }
        }
      } else {
        const el = document.getElementById(key + "-2");
        if (el) {
          el.value = DataCustomer[key];
        }
      }
    });
  };
  // Products
  const products = {
    lite: "BD0000017",
    pro: "BD0000015",
    expert: "BD0000021",
    Tablet: "HW0000030",
    OwnTablet: "HW0000024",
    Printer: "HW0000029",
    NoPrinter: "HW0000035",
    vb: "",
    cc: "",
    analytics: "BD0000018",
    car: "",
    mm: "AD0000005;AD0000013",
  };
  // SF call
  const sendToSf = (unparsedData, action) => {
    // Getting products list
    let ProductsChosen = [products.lite];
    // Get hardware
    ProductsChosen.push(products["NoPrinter"]);
    const printerProdKey =
      parseInt(unparsedData.printers) == 0 ? "NoPrinter" : "Printer";
    ProductsChosen.push(products[printerProdKey]);

    if (parseInt(unparsedData.tablets) > 0) {
      ProductsChosen.push(products.Tablet);
    }
    if (unparsedData["Own-Tablet"]) {
      ProductsChosen.push(products.OwnTablet);
    }
    Object.keys(Addons).forEach((key) => {
      if (products[key]) {
        if (Addons[key].selected && Addons[key].isCharged) {
          ProductsChosen.push(products[key]);
        }
      }
    });
    const parsedData = {
      query: `email = '${unparsedData.Email}' AND country__c = '${unparsedData.Country}' AND (LeadSource = 'Inbound - Self Service') AND (Hubster_step__c = 'Creation' OR Hubster_step__c = 'Product_selection')`,
      "# Locations": unparsedData.Locations,
      "# Tablets": unparsedData.tablets,
      "# Printers": unparsedData.printers,
      Street: unparsedData.Address + " " + unparsedData.Apt,
      City: unparsedData.City,
      State: unparsedData.State,
      Zip: unparsedData["Postal-Code"],
      Products: ProductsChosen.join(";"),
      LastName: unparsedData.Name + " " + unparsedData.LastName,
      Company: unparsedData.Restaurant,
      "Mobile Phone": PhoneCode + unparsedData.Phone,
    };
    fetch("https://hooks.zapier.com/hooks/catch/1999765/b2vch1d/", {
      method: "POST",
      headers: {},
      body: JSON.stringify(parsedData),
      redirect: "follow",
    })
      .then((response) => response.json())
      .then(() => {
        action();
      })
      .catch((error) => console.log("error", error));
  };
  // Render AddOns
  Object.keys(DataCustomer.addOns).forEach((key, indx) => {
    const check = document.getElementById(key + "Check");
    const row = document.getElementById(key + "Row");
    if (row && !DataCustomer.addOns[key].selected) {
      row.style.display = "none";
    }
    if (check) {
      if (DataCustomer.addOns[key].selected) {
        check.click();
        document
          .getElementById(key + "Ui")
          .getElementsByTagName("div")[0]
          .classList.add("w--redirected-checked");
      }
      check.addEventListener("change", (e) => {
        DataCustomer.addOns[key].selected = e.target.checked;
        renderTotal();
      });
    }
    if (key === "vb") {
      const number = document.getElementById(key + "Number");
      number.value = DataCustomer.addOns.vb.number;
      number.addEventListener("change", () => {
        renderTotal();
      });
    }
  });
  // Start with logic and listeners
  locations.addEventListener("change", (e) => {
    if (parseInt(e.target.value) < parseInt(tablets.value)) {
      tablets.value = e.target.value;
    }
    if (parseInt(e.target.value) < parseInt(printers.value)) {
      printers.value = e.target.value;
    }
    renderTotal();
  });
  tablets.addEventListener("change", (e) => {
    if (parseInt(e.target.value) > parseInt(locations.value)) {
      e.target.value = locations.value;
    }
    renderTotal();
  });
  printers.addEventListener("change", (e) => {
    if (parseInt(e.target.value) > parseInt(locations.value)) {
      e.target.value = locations.value;
    }
    renderTotal();
  });
  termsCheck.onchange = (e) => {
    e.target.setCustomValidity("");
  };
  locations.oninput = (e) => {
    e.target.setCustomValidity("");
  };
  editBtn.addEventListener("click", () => {
    renderCustomerData(false);
  });
  saveBtn.addEventListener("click", (e) => {
    e.preventDefault();
    let formData = {};
    let valid = true;
    [...emailForm.elements].reverse().forEach((element) => {
      valid *= element.checkValidity();
      element.oninput = (e) => {
        e.target.setCustomValidity("");
      };
      formData[element.name] = element.value;
      if (!element.checkValidity()) {
        element.setCustomValidity("Please check or fill this field");
        element.reportValidity();
        return;
      }
    });
    if (valid) {
      Object.keys(formData).forEach((key) => {
        DataCustomer[key] = formData[key];
      });
      renderCustomerData(true);
      localStorage.setItem("DataCustomer", JSON.stringify(DataCustomer));
      saveBtn.style.display = "none";
      editBtn.style.display = "flex";
      document.getElementById("nonEditable").style.display = "block";
      document.getElementById("editable").style.display = "none";
    }
  });
  nextBtn.addEventListener("click", (e) => {
    e.preventDefault();
    let formData = {};
    //validate non edit state
    if (saveBtn.style.display === "flex") {
      saveBtn.click();
    } else {
      //validate locations
      if (parseInt(locations.value) === 0 || locations.value === "") {
        locations.setCustomValidity(
          "Please select the number of Locations you need"
        );
        locations.reportValidity();
      } else {
        //validate address form
        let valid = true;
        [...addressForm.elements].reverse().forEach((element) => {
          valid *= element.checkValidity();
          element.oninput = (e) => {
            e.target.setCustomValidity("");
          };
          formData[element.name] = element.value;
          if (!element.checkValidity()) {
            element.setCustomValidity("Please check or fill this field");
            element.reportValidity();
            return;
          }
        });
        if (valid) {
          //validate terms of service
          if (termsCheck.checked) {
            const paymentKey = Date.now();
            const options = {
              checkoutToken: moonClrkDomains[window.location.host],
              width: "100%",
              amount_cents: grandTotal * 100,
              email: DataCustomer.Email,
              name: DataCustomer.Name + " " + DataCustomer.LastName,
              cid: paymentKey,
            };
            const newData = {
              ...DataCustomer,
              ...DataAddress,
              Locations: locations.value,
            };
            localStorage.setItem("options", JSON.stringify(options));
            localStorage.setItem("DataCustomer", JSON.stringify(newData));
            localStorage.setItem("PaymentKey", paymentKey);
            sendToSf(newData, () => {
              location.href = "/payment";
            });
          } else {
            termsCheck.setCustomValidity(
              "Accept the Terms of Service before continue to Payment"
            );
            termsCheck.reportValidity();
          }
        }
      }
    }
  });
  // Initial Values
  locations.value = DataCustomer.Locations;
  printers.value = DataCustomer.Printers;
  tablets.value = DataCustomer.Tablets;
  if (DataCustomer.OwnTablet) {
    tablets.disabled = true;
  }
  renderCustomerData(true);
  renderTotal();
});

//*************** PRO ADDONS SCRIPT ***************//
document.addEventListener("DOMContentLoaded", () => {
  if (localStorage.getItem("Paid")) location.href = "/activate";
  if (localStorage.getItem("DataCustomer") === null) {
    location.href = "/checkout/signup";
  }
  // Set vars and functions
  const DataCustomer = JSON.parse(localStorage.getItem("DataCustomer"));
  const currency = "£";
  const sepCents = ".";
  const sepThousands = ",";
  const numberCents = sepCents + "00";
  const nextBtn = document.getElementById("nextBtn");
  const total = document.getElementById("total");
  const locations = document.getElementById("locations");
  const price = parseInt(
    document.getElementById("price").innerHTML.replace(currency, "")
  );
  const tablets = document.getElementById("tablets");
  const tabletsPrice = parseInt(
    document.getElementById("tabletsPrice").innerHTML.replace(currency, "")
  );
  const printers = document.getElementById("printers");
  const printersPrice = parseInt(
    document.getElementById("printersPrice").innerHTML.replace(currency, "")
  );
  const ownTablet = document.getElementById("ownTablet");
  const addOns = {
    car: {
      selected: false,
      price: 0,
      name: "",
    },
    mm: {
      selected: false,
      price: 0,
      name: "",
    },
    pos: {
      selected: false,
      price: 0,
      name: "",
    },
  };
  const numberWithFormat = (number) => {
    return (
      currency +
      number.toString().replace(/\B(?=(\d{3})+(?!\d))/g, sepThousands) +
      numberCents
    );
  };
  const renderTotal = () => {
    let amount = parseInt(
      locations.value * price +
        tablets.value * (DataCustomer.tabletFree ? 0 : tabletsPrice) +
        printers.value * (DataCustomer.printerFree ? 0 : printersPrice)
    );
    Object.keys(addOns).forEach((key) => {
      const addon = addOns[key];
      if (key === "vb") {
        amount += addon.selected * (addon.price * addon.number);
      } else {
        amount += addon.selected * (addon.price * locations.value);
      }
    });
    total.innerHTML = numberWithFormat(amount);
    document.getElementById("tabletsPrice").style.textDecoration =
      DataCustomer.tabletFree ? "line-through" : "none";
    document.getElementById("printersPrice").style.textDecoration =
      DataCustomer.printerFree ? "line-through" : "none";
  };
  // Initialize Custom Validity
  locations.oninput = (e) => {
    e.target.setCustomValidity("");
  };
  printers.oninput = (e) => {
    e.target.setCustomValidity("");
  };
  tablets.oninput = (e) => {
    e.target.setCustomValidity("");
  };
  // Set listeners
  locations.addEventListener("change", (e) => {
    if (parseInt(e.target.value) < parseInt(tablets.value)) {
      tablets.value = e.target.value;
    }
    if (parseInt(e.target.value) < parseInt(printers.value)) {
      printers.value = e.target.value;
    }
    renderTotal();
  });
  printers.addEventListener("change", (e) => {
    if (parseInt(e.target.value) > parseInt(locations.value)) {
      e.target.value = locations.value;
    }
    if (e.target.value > 0 && (tablets.value <= 0 || tablets.value === "")) {
      DataCustomer["tabletFree"] = false;
      DataCustomer["printerFree"] = true;
    } else {
      DataCustomer["tabletFree"] = true;
      DataCustomer["printerFree"] = false;
    }
    renderTotal();
  });
  tablets.addEventListener("change", (e) => {
    if (parseInt(e.target.value) > parseInt(locations.value)) {
      e.target.value = locations.value;
    }
    if (e.target.value > 0 && (printers.value <= 0 || printers.value === "")) {
      DataCustomer["tabletFree"] = true;
      DataCustomer["printerFree"] = false;
    } else {
      DataCustomer["tabletFree"] = false;
      DataCustomer["printerFree"] = true;
    }
    renderTotal();
  });
  ownTablet.addEventListener("click", (e) => {
    if (e.currentTarget.checked) {
      tablets.value = 0;
      tablets.disabled = true;
      DataCustomer["tabletFree"] = false;
      DataCustomer["printerFree"] = true;
    } else {
      tablets.disabled = false;
    }
    renderTotal();
  });
  nextBtn.addEventListener("click", (e) => {
    e.preventDefault();
    let valid = true;
    if (locations.value <= 0) {
      valid = false;
      locations.setCustomValidity(
        "Please select the number of Locations you need"
      );
      locations.reportValidity();
    } else if (
      (tablets.value <= 0 || tablets.value === "") &&
      !ownTablet.checked
    ) {
      valid = false;
      tablets.setCustomValidity(
        "Please select at least 1 Tablet or Check 'I already have my own tablet"
      );
      tablets.reportValidity();
    }
    if (valid) {
      localStorage.setItem(
        "DataCustomer",
        JSON.stringify({
          ...DataCustomer,
          Locations: locations.value,
          Printers: printers.value,
          PrintersPrice: printersPrice,
          Tablets: tablets.value,
          TabletsPrice: tabletsPrice,
          OwnTablet: ownTablet.checked,
          addOns,
        })
      );
      location.href = "/checkout/confirm-info-pro";
    }
  });
  // Set listeners to Add Ons
  Object.keys(addOns).forEach((key) => {
    addOns[key].name = document.getElementById(key + "Name").innerHTML;
    addOns[key].price = parseInt(
      document.getElementById(key + "Price").innerHTML.replace(currency, "")
    );
    document.getElementById(key + "Btn").addEventListener("click", () => {
      if (document.getElementById(key + "Added").style.display !== "flex") {
        addOns[key].selected = true;
      } else {
        addOns[key].selected = false;
      }
      renderTotal();
    });
  });
  // Initialize input number to make life easier and first render
  locations.value = DataCustomer.Locations;
  printers.value = 0;
  tablets.value = 0;
  printers.attributes.max = DataCustomer.Locations;
  tablets.attributes.max = DataCustomer.Locations;
  renderTotal();
});

//*************** PRO CONFIRM SCRIPT ***************//
document.addEventListener("DOMContentLoaded", () => {
  if (localStorage.getItem("Paid")) location.href = "/activate";
  if (localStorage.getItem("DataCustomer") === null) {
    location.href = "/checkout/signup";
  }
  // Set vars and functions
  let grandTotal = 0;
  const DataCustomer = JSON.parse(localStorage.getItem("DataCustomer"));
  const DataAddress = {};
  const currency = "£";
  const sepCents = ".";
  const sepThousands = ",";
  const numberCents = sepCents + "00";
  const tax = 0.2;
  const editBtn = document.getElementById("editBtn");
  const nextBtn = document.getElementById("nextBtn");
  const saveBtn = document.getElementById("saveBtn");
  const total = document.getElementById("total");
  const total2 = document.getElementById("total2");
  const totalPrice = document.getElementById("totalPrice");
  const totalTax = document.getElementById("totalTax");
  const locations = document.getElementById("locations");
  const printers = document.getElementById("printers");
  const printersTotal = document.getElementById("printersTotal");
  const tablets = document.getElementById("tablets");
  const tabletsTotal = document.getElementById("tabletsTotal");
  const emailForm = document.getElementById("email-form");
  const addressForm = document.getElementById("addressForm");
  const termsCheck = document.getElementById("termsService");
  const moonClrkDomains = {
    "otter-uk.webflow.io": "7bi82h0v5y84",
    "www.tryotter.uk": "xr8wzpmpsnp",
  };
  const price = parseInt(
    document
      .getElementById("price")
      .innerHTML.replace(currency, "")
      .replace(sepThousands, "")
  );
  const numberWithFormat = (number) => {
    return (
      currency +
      number
        .toFixed(2)
        .toString()
        .replace(/\B(?=(\d{3})+(?!\d))/g, sepThousands)
    );
  };
  const renderTotal = () => {
    const amountLocations = parseInt(locations.value * price);
    const amountPrinters = parseInt(
      printers.value * DataCustomer.PrintersPrice
    );
    const amountTablets = parseInt(tablets.value * DataCustomer.TabletsPrice);
    let amount = amountLocations + amountPrinters + amountTablets;
    Object.keys(DataCustomer.addOns).forEach((key) => {
      const addon = DataCustomer.addOns[key];
      if (key !== "vb") {
        const addonPrice = addon.selected * (addon.price * locations.value);
        document.getElementById(key + "Total").innerHTML =
          numberWithFormat(addonPrice);
        amount += addonPrice;
      }
    });
    if (DataCustomer.tabletFree) {
      tabletsTotal.style.textDecoration = "line-through";
      amount -= amountTablets;
    } else {
      tabletsTotal.style.textDecoration = "none";
    }
    if (DataCustomer.printerFree) {
      printersTotal.style.textDecoration = "line-through";
      amount -= amountPrinters;
    } else {
      printersTotal.style.textDecoration = "none";
    }
    const amountTax = amount * tax;
    grandTotal = amount + amountTax;
    totalPrice.innerHTML = numberWithFormat(amount);
    printersTotal.innerHTML = numberWithFormat(amountPrinters);
    tabletsTotal.innerHTML = numberWithFormat(amountTablets);
    totalTax.innerHTML = numberWithFormat(amountTax);
    total.innerHTML = numberWithFormat(grandTotal);
    total2.innerHTML = numberWithFormat(grandTotal);
  };
  const renderCustomerData = (read) => {
    Object.keys(DataCustomer).forEach((key) => {
      if (read) {
        const el = document.getElementById(key + "R");
        if (el) {
          if (key === "Name") {
            el.innerHTML = DataCustomer[key] + " " + DataCustomer["LastName"];
          } else {
            el.innerHTML = DataCustomer[key];
          }
        }
      } else {
        const el = document.getElementById(key + "-2");
        if (el) {
          el.value = DataCustomer[key];
        }
      }
    });
  };
  // Products
  const products = {
    lite: "BD0000017",
    pro: "BD0000015",
    expert: "BD0000021",
    Tablet: "HW0000030",
    OwnTablet: "HW0000024",
    Printer: "HW0000029",
    NoPrinter: "HW0000035",
    vb: "",
    cc: "",
    analytics: "BD0000018",
    car: "",
    mm: "AD0000005;AD0000013",
  };
  // SF call
  const sendToSf = (unparsedData, action) => {
    // Getting products list
    let ProductsChosen = [products.pro];
    // Get hardware
    ProductsChosen.push(products["NoPrinter"]);
    const printerProdKey =
      parseInt(unparsedData.printers) == 0 ? "NoPrinter" : "Printer";
    ProductsChosen.push(products[printerProdKey]);

    if (parseInt(unparsedData.tablets) > 0) {
      ProductsChosen.push(products.Tablet);
    }
    if (unparsedData["Own-Tablet"]) {
      ProductsChosen.push(products.OwnTablet);
    }
    Object.keys(Addons).forEach((key) => {
      if (products[key]) {
        if (Addons[key].selected && Addons[key].isCharged) {
          ProductsChosen.push(products[key]);
        }
      }
    });
    const parsedData = {
      query: `email = '${unparsedData.Email}' AND country__c = '${unparsedData.Country}' AND (LeadSource = 'Inbound - Self Service') AND (Hubster_step__c = 'Creation' OR Hubster_step__c = 'Product_selection')`,
      "# Locations": unparsedData.Locations,
      "# Tablets": unparsedData.tablets,
      "# Printers": unparsedData.printers,
      Street: unparsedData.Address + " " + unparsedData.Apt,
      City: unparsedData.City,
      State: unparsedData.State,
      Zip: unparsedData["Postal-Code"],
      Products: ProductsChosen.join(";"),
      LastName: unparsedData.Name + " " + unparsedData.LastName,
      Company: unparsedData.Restaurant,
      "Mobile Phone": PhoneCode + unparsedData.Phone,
    };
    fetch("https://hooks.zapier.com/hooks/catch/1999765/b2vch1d/", {
      method: "POST",
      headers: {},
      body: JSON.stringify(parsedData),
      redirect: "follow",
    })
      .then((response) => response.json())
      .then(() => {
        action();
      })
      .catch((error) => console.log("error", error));
  };
  // Render AddOns
  Object.keys(DataCustomer.addOns).forEach((key) => {
    const check = document.getElementById(key + "Check");
    const row = document.getElementById(key + "Row");
    if (row && !DataCustomer.addOns[key].selected) {
      row.style.display = "none";
    }
    if (check) {
      if (DataCustomer.addOns[key].selected) {
        check.click();
        document
          .getElementById(key + "Ui")
          .getElementsByTagName("div")[0]
          .classList.add("w--redirected-checked");
      }
      check.addEventListener("change", (e) => {
        DataCustomer.addOns[key].selected = e.target.checked;
        renderTotal();
      });
    }
  });
  // Start with logic and listeners
  tablets.addEventListener("change", (e) => {
    if (parseInt(e.target.value) > parseInt(locations.value)) {
      e.target.value = locations.value;
    }
    if (e.target.value > 0 && (printers.value <= 0 || printers.value === "")) {
      DataCustomer["tabletFree"] = true;
      DataCustomer["printerFree"] = false;
    } else {
      DataCustomer["tabletFree"] = false;
      DataCustomer["printerFree"] = true;
    }
    renderTotal();
  });
  printers.addEventListener("change", (e) => {
    if (parseInt(e.target.value) > parseInt(locations.value)) {
      e.target.value = locations.value;
    }
    if (e.target.value > 0 && (tablets.value <= 0 || tablets.value === "")) {
      DataCustomer["tabletFree"] = false;
      DataCustomer["printerFree"] = true;
    } else {
      DataCustomer["tabletFree"] = true;
      DataCustomer["printerFree"] = false;
    }
    renderTotal();
  });
  locations.addEventListener("change", (e) => {
    if (parseInt(e.target.value) < parseInt(tablets.value)) {
      tablets.value = e.target.value;
    }
    if (parseInt(e.target.value) < parseInt(printers.value)) {
      printers.value = e.target.value;
    }
    renderTotal();
  });
  locations.oninput = (e) => {
    e.target.setCustomValidity("");
  };
  termsCheck.onchange = (e) => {
    e.target.setCustomValidity("");
  };
  editBtn.addEventListener("click", () => {
    renderCustomerData(false);
  });
  saveBtn.addEventListener("click", (e) => {
    e.preventDefault();
    let formData = {};
    let valid = true;
    [...emailForm.elements].reverse().forEach((element) => {
      valid *= element.checkValidity();
      element.oninput = (e) => {
        e.target.setCustomValidity("");
      };
      formData[element.name] = element.value;
      if (!element.checkValidity()) {
        element.setCustomValidity("Please check or fill this field");
        element.reportValidity();
        return;
      }
    });
    if (valid) {
      Object.keys(formData).forEach((key) => {
        DataCustomer[key] = formData[key];
      });
      renderCustomerData(true);
      localStorage.setItem("DataCustomer", JSON.stringify(DataCustomer));
      saveBtn.style.display = "none";
      editBtn.style.display = "flex";
      document.getElementById("nonEditable").style.display = "block";
      document.getElementById("editable").style.display = "none";
    }
  });
  nextBtn.addEventListener("click", (e) => {
    e.preventDefault();
    let formData = {};
    //validate non edit state
    if (saveBtn.style.display === "flex") {
      saveBtn.click();
    }
    if (saveBtn.style.display !== "flex") {
      //validate locations
      if (parseInt(locations.value) === 0 || locations.value === "") {
        locations.setCustomValidity(
          "Please select the number of Locations you need"
        );
        locations.reportValidity();
      } else {
        //validate address form
        let valid = true;
        [...addressForm.elements].reverse().forEach((element) => {
          valid *= element.checkValidity();
          element.oninput = (e) => {
            e.target.setCustomValidity("");
          };
          formData[element.name] = element.value;
          if (!element.checkValidity()) {
            element.setCustomValidity("Please check or fill this field");
            element.reportValidity();
            return;
          }
        });
        if (valid) {
          //validate terms of service
          if (termsCheck.checked) {
            const paymentKey = Date.now();
            const options = {
              checkoutToken: moonClrkDomains[window.location.host],
              width: "100%",
              amount_cents: grandTotal * 100,
              email: DataCustomer.Email,
              name: DataCustomer.Name + " " + DataCustomer.LastName,
              cid: paymentKey,
            };
            const newData = {
              ...DataCustomer,
              ...DataAddress,
              Locations: locations.value,
            };
            localStorage.setItem("options", JSON.stringify(options));
            localStorage.setItem("DataCustomer", JSON.stringify(newData));
            localStorage.setItem("PaymentKey", paymentKey);
            sendToSf(newData, () => {
              location.href = "/payment";
            });
          } else {
            termsCheck.setCustomValidity(
              "Accept the Terms of Service before continue to Payment"
            );
            termsCheck.reportValidity();
          }
        }
      }
    }
  });
  // Initial Values
  locations.value = DataCustomer.Locations;
  printers.value = DataCustomer.Printers;
  tablets.value = DataCustomer.Tablets;
  if (DataCustomer.OwnTablet) {
    tablets.disabled = true;
  }
  renderCustomerData(true);
  renderTotal();
});

//*************** EXPERT CONFIRM SCRIPT ***************//
document.addEventListener("DOMContentLoaded", () => {
  if (localStorage.getItem("Paid")) location.href = "/activate";
  if (localStorage.getItem("DataCustomer") === null) {
    location.href = "/checkout/signup";
  }
  // Set vars and functions
  let grandTotal = 0;
  const DataCustomer = JSON.parse(localStorage.getItem("DataCustomer"));
  const DataAddress = {};
  const currency = "£";
  const sepCents = ".";
  const sepThousands = ",";
  const numberCents = sepCents + "00";
  const tax = 0.2;
  const editBtn = document.getElementById("editBtn");
  const nextBtn = document.getElementById("nextBtn");
  const saveBtn = document.getElementById("saveBtn");
  const total = document.getElementById("total");
  const total2 = document.getElementById("total2");
  const totalPrice = document.getElementById("totalPrice");
  const totalTax = document.getElementById("totalTax");
  const locations = document.getElementById("locations");
  const emailForm = document.getElementById("email-form");
  const addressForm = document.getElementById("addressForm");
  const termsCheck = document.getElementById("termsService");
  const moonClrkDomains = {
    "otter-uk.webflow.io": "7bi82h0v5y84",
    "www.tryotter.uk": "xr8wzpmpsnp",
  };
  const price = parseInt(
    document
      .getElementById("price")
      .innerHTML.replace(currency, "")
      .replace(sepThousands, "")
  );
  const numberWithFormat = (number) => {
    return (
      currency +
      number
        .toFixed(2)
        .toString()
        .replace(/\B(?=(\d{3})+(?!\d))/g, sepThousands)
    );
  };
  const renderTotal = () => {
    const amount = parseInt(locations.value * price);
    const amountTax = amount * tax;
    grandTotal = amount + amountTax;
    totalPrice.innerHTML = numberWithFormat(amount);
    totalTax.innerHTML = numberWithFormat(amountTax);
    total.innerHTML = numberWithFormat(grandTotal);
    total2.innerHTML = numberWithFormat(grandTotal);
  };
  const renderCustomerData = (read) => {
    Object.keys(DataCustomer).forEach((key) => {
      if (read) {
        const el = document.getElementById(key + "R");
        if (el) {
          if (key === "Name") {
            el.innerHTML = DataCustomer[key] + " " + DataCustomer["LastName"];
          } else {
            el.innerHTML = DataCustomer[key];
          }
        }
      } else {
        const el = document.getElementById(key + "-2");
        if (el) {
          el.value = DataCustomer[key];
        }
      }
    });
  };
  // Products
  const products = {
    lite: "BD0000017",
    pro: "BD0000015",
    expert: "BD0000021",
    Tablet: "HW0000030",
    OwnTablet: "HW0000024",
    Printer: "HW0000029",
    NoPrinter: "HW0000035",
    vb: "",
    cc: "",
    analytics: "BD0000018",
    car: "",
    mm: "AD0000005;AD0000013",
  };
  // SF call
  const sendToSf = (unparsedData, action) => {
    // Getting products list
    let ProductsChosen = [products.expert];
    // Get hardware
    const parsedData = {
      query: `email = '${unparsedData.Email}' AND country__c = '${unparsedData.Country}' AND (LeadSource = 'Inbound - Self Service') AND (Hubster_step__c = 'Creation' OR Hubster_step__c = 'Product_selection')`,
      "# Locations": unparsedData.Locations,
      "# Tablets": unparsedData.tablets,
      "# Printers": unparsedData.printers,
      Street: unparsedData.Address + " " + unparsedData.Apt,
      City: unparsedData.City,
      State: unparsedData.State,
      Zip: unparsedData["Postal-Code"],
      Products: ProductsChosen.join(";"),
      LastName: unparsedData.Name + " " + unparsedData.LastName,
      Company: unparsedData.Restaurant,
      "Mobile Phone": PhoneCode + unparsedData.Phone,
    };
    fetch("https://hooks.zapier.com/hooks/catch/1999765/b2vch1d/", {
      method: "POST",
      headers: {},
      body: JSON.stringify(parsedData),
      redirect: "follow",
    })
      .then((response) => response.json())
      .then(() => {
        action();
      })
      .catch((error) => console.log("error", error));
  };
  // Start with logic
  termsCheck.onchange = (e) => {
    e.target.setCustomValidity("");
  };
  locations.addEventListener("change", () => {
    renderTotal();
  });
  locations.oninput = (e) => {
    e.target.setCustomValidity("");
  };
  editBtn.addEventListener("click", () => {
    renderCustomerData(false);
  });
  saveBtn.addEventListener("click", (e) => {
    e.preventDefault();
    let formData = {};
    let valid = true;
    [...emailForm.elements].reverse().forEach((element) => {
      valid *= element.checkValidity();
      element.oninput = (e) => {
        e.target.setCustomValidity("");
      };
      formData[element.name] = element.value;
      if (!element.checkValidity()) {
        element.setCustomValidity("Please check or fill this field");
        element.reportValidity();
        return;
      }
    });
    if (valid) {
      Object.keys(formData).forEach((key) => {
        DataCustomer[key] = formData[key];
      });
      renderCustomerData(true);
      localStorage.setItem("DataCustomer", JSON.stringify(DataCustomer));
      saveBtn.style.display = "none";
      editBtn.style.display = "flex";
      document.getElementById("nonEditable").style.display = "block";
      document.getElementById("editable").style.display = "none";
    }
  });
  nextBtn.addEventListener("click", (e) => {
    e.preventDefault();
    let formData = {};
    //validate non edit state
    if (saveBtn.style.display === "flex") {
      saveBtn.click();
    }
    if (saveBtn.style.display !== "flex") {
      //validate locations
      if (parseInt(locations.value) === 0 || locations.value === "") {
        locations.setCustomValidity(
          "Please select the number of Locations you need"
        );
        locations.reportValidity();
      } else {
        //validate address form
        let valid = true;
        [...addressForm.elements].reverse().forEach((element) => {
          valid *= element.checkValidity();
          element.oninput = (e) => {
            e.target.setCustomValidity("");
          };
          formData[element.name] = element.value;
          if (!element.checkValidity()) {
            element.setCustomValidity("Please check or fill this field");
            element.reportValidity();
            return;
          }
        });
        if (valid) {
          //validate terms of service
          if (termsCheck.checked) {
            const paymentKey = Date.now();
            const options = {
              checkoutToken: moonClrkDomains[window.location.host],
              width: "100%",
              amount_cents: grandTotal * 100,
              email: DataCustomer.Email,
              name: DataCustomer.Name + " " + DataCustomer.LastName,
              cid: paymentKey,
            };
            const newData = {
              ...DataCustomer,
              ...DataAddress,
              Locations: locations.value,
            };
            localStorage.setItem("options", JSON.stringify(options));
            localStorage.setItem("DataCustomer", JSON.stringify(newData));
            localStorage.setItem("PaymentKey", paymentKey);
            sendToSf(newData, () => {
              location.href = "/payment";
            });
          } else {
            termsCheck.setCustomValidity(
              "Accept the Terms of Service before continue to Payment"
            );
            termsCheck.reportValidity();
          }
        }
      }
    }
  });
  // Initial Values
  locations.value = DataCustomer.Locations;
  renderCustomerData(true);
  renderTotal();
});

//*************** CONNECT PAYMENT SCRIPT ***************//
document.addEventListener("DOMContentLoaded", () => {
  const firstPage = "/checkout/signup";
  const PaymentKey = localStorage.getItem("PaymentKey");
  if (PaymentKey === null && !localStorage.getItem("Paid")) {
    location.href = firstPage;
  }
  const strCustomerData = localStorage.getItem("DataCustomer");
  const DataCustomer = JSON.parse(strCustomerData);
  const countryCode = "UK";
  const urlParams = new URLSearchParams(window.location.search);
  const paymentReceived = urlParams.get("custom_id") === PaymentKey;
  const paymentId = urlParams.get("customer_id");
  const sendToSf = (unparsedData, action = () => {}) => {
    const parsedData = {
      query: `email = '${unparsedData.Email}' AND country__c = '${unparsedData.Country}' AND LeadSource = 'Inbound - Self Service' AND Hubster_step__c = 'Product_Selection'`,
      PaymentID: countryCode + paymentId,
      PaymentReceived: paymentReceived,
    };
    if (paymentReceived && paymentId) {
      localStorage.setItem("customer_id", paymentId);
      fetch("https://hooks.zapier.com/hooks/catch/1999765/bb2j69g/", {
        method: "POST",
        headers: {},
        body: JSON.stringify(parsedData),
        redirect: "follow",
      })
        .then((response) => response.json())
        .then(() => {
          action();
        })
        .catch((error) => console.log("error", error));
    }
  };

  sendToSf(DataCustomer, () => {
    localStorage.removeItem("PaymentKey");
    localStorage.setItem("Paid", true);
    localStorage.clear();
    location.href = `https://manager.tryotter.com/sign-up?email=${DataCustomer.Email}&country=${DataCustomer.Country}&phone=%2B44%20${DataCustomer["Phone-Number"]}&name=${DataCustomer.Name}%20${DataCustomer.LastName}&restaurantName=${DataCustomer["Restaurant-Name"]}`;
  });
});
